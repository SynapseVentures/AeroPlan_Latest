import os
import subprocess
import sys
import platform
import time


def print_step(message):
    """Print a step message with formatting"""
    print("\n" + "=" * 50)
    print(message)
    print("=" * 50)


def check_python_version():
    """Check if Python version is 3.8 or higher"""
    required_version = (3, 8)
    current_version = sys.version_info[:2]

    if current_version < required_version:
        print(
            f"ERROR: Python {required_version[0]}.{required_version[1]} or higher is required"
        )
        print(f"Current version: Python {current_version[0]}.{current_version[1]}")
        return False
    return True


def setup_environment():
    """Set up the virtual environment and install requirements"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    venv_path = os.path.join(base_dir, ".venv")

    # Create virtual environment
    print_step("Creating virtual environment...")
    try:
        subprocess.run([sys.executable, "-m", "venv", venv_path], check=True)
        print("✓ Virtual environment created successfully")
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Failed to create virtual environment: {e}")
        return False

    # Get the correct paths based on OS
    if platform.system() == "Windows":
        python_path = os.path.join(venv_path, "Scripts", "python")
        pip_path = os.path.join(venv_path, "Scripts", "pip")
    else:
        python_path = os.path.join(venv_path, "bin", "python")
        pip_path = os.path.join(venv_path, "bin", "pip")

    # Upgrade pip
    print_step("Upgrading pip...")
    try:
        subprocess.run(
            [python_path, "-m", "pip", "install", "--upgrade", "pip"], check=True
        )
        print("✓ Pip upgraded successfully")
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Failed to upgrade pip: {e}")
        return False

    # Install requirements
    print_step("Installing required packages...")
    # Use an absolute path for requirements.txt
    requirements_path = os.path.join(base_dir, "requirements.txt")
    try:
        subprocess.run([pip_path, "install", "-r", requirements_path], check=True)
        print("✓ Requirements installed successfully")
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Failed to install requirements: {e}")
        return False

    return True


def create_directories():
    """Verify that necessary directories exist."""
    print_step("Verifying application directories...")
    base_dir = os.path.dirname(os.path.abspath(__file__))
    outputs_dir = os.path.join(base_dir, "outputs")
    temp_dir = os.path.join(outputs_dir, "temp")

    if not os.path.exists(outputs_dir):
        print(
            "ERROR: 'outputs' folder not found! Please ensure it is delivered with the package."
        )
        return False

    if not os.path.exists(temp_dir):
        print(
            "ERROR: 'outputs/temp' folder not found! Please ensure it is delivered with the package."
        )
        return False

    print("✓ Output directories verified successfully")
    return True


def main():
    print("\nAeroPlan Light™ Installation")
    print("=" * 50)

    # Check Python version
    print_step("Checking Python version...")
    if not check_python_version():
        input("\nPress Enter to exit...")
        return False

    # Setup virtual environment and install packages
    if not setup_environment():
        input("\nPress Enter to exit...")
        return False

    # Create necessary directories
    if not create_directories():
        input("\nPress Enter to exit...")
        return False

    print_step("Installation completed successfully!")
    print("\nTo start AeroPlan Light™:")
    print("1. Double-click 'run.py' or")
    if platform.system() == "Windows":
        print("2. Run in terminal: python run.py")
    else:
        print("2. Run in terminal: python3 run.py")

    print("\nInstallation will close in 5 seconds...")
    time.sleep(5)
    return True


if __name__ == "__main__":
    main()
