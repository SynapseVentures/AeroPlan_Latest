import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime, timedelta
import pandas as pd
import glob
import os
import gantt_chart  # Assumes gantt_chart.py is in the same directory

# Define default effort values (in hours) per component type.
DEFAULT_EFFORTS = {
    "Single Part": {"Check": 5, "Release": 3},
    "Sub-Assembly": {"Check": 6, "Release": 4},
    "Assembly": {"Check": 11, "Release": 5},
    "Design Solution": {"Check": 11, "Release": 5},
}

# Define default weekly capacity (in hours)
CAPACITY_CHECK = 35
CAPACITY_RELEASE = 35


class ClashAnalysisTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.schedule_data = None  # Loaded schedule data (from LtoR or RtoL)
        self.original_schedule = None  # Preserved original schedule (pre-delay)
        self.part_list = None  # Loaded part list data
        self.delayed_schedule = None  # Delayed schedule after applying delay
        self.loaded_schedule_file = None  # File path from which the schedule was loaded
        self.setup_ui()
        self.load_partlist()  # Populate the part selection menu

    def setup_ui(self):
        # Top frame for schedule selection and delay parameters
        top_frame = ctk.CTkFrame(self)
        top_frame.pack(padx=10, pady=10, fill="x")

        # Schedule selection
        ctk.CTkLabel(top_frame, text="Select Schedule:").grid(
            row=0, column=0, padx=5, pady=5, sticky="w"
        )
        self.schedule_option = ctk.CTkOptionMenu(top_frame, values=["LtoR", "RtoL"])
        self.schedule_option.grid(row=0, column=1, padx=5, pady=5)
        load_sched_btn = ctk.CTkButton(
            top_frame, text="Load Schedule", command=self.load_schedule
        )
        load_sched_btn.grid(row=0, column=2, padx=5, pady=5)

        # Part selection from the part list (loaded separately)
        ctk.CTkLabel(top_frame, text="Select Part:").grid(
            row=1, column=0, padx=5, pady=5, sticky="w"
        )
        self.part_option = ctk.CTkOptionMenu(top_frame, values=[])
        self.part_option.grid(row=1, column=1, padx=5, pady=5)

        # Delay input (in weeks)
        ctk.CTkLabel(top_frame, text="Delay (weeks):").grid(
            row=2, column=0, padx=5, pady=5, sticky="w"
        )
        self.delay_entry = ctk.CTkEntry(
            top_frame, width=100, placeholder_text="Enter delay in weeks"
        )
        self.delay_entry.grid(row=2, column=1, padx=5, pady=5)

        # Phase selection: Check or Release
        ctk.CTkLabel(top_frame, text="Delay applies to:").grid(
            row=3, column=0, padx=5, pady=5, sticky="w"
        )
        self.phase_var = tk.StringVar(value="Check")
        check_radio = ctk.CTkRadioButton(
            top_frame, text="Check Phase", variable=self.phase_var, value="Check"
        )
        release_radio = ctk.CTkRadioButton(
            top_frame, text="Release Phase", variable=self.phase_var, value="Release"
        )
        check_radio.grid(row=3, column=1, padx=5, pady=5, sticky="w")
        release_radio.grid(row=3, column=2, padx=5, pady=5, sticky="w")

        # Apply delay button
        apply_btn = ctk.CTkButton(
            top_frame, text="Apply Delay", command=self.apply_delay
        )
        apply_btn.grid(row=4, column=0, columnspan=3, padx=5, pady=10)

        # Frame for displaying delayed schedule in a table view
        table_frame = ctk.CTkFrame(self)
        table_frame.pack(padx=10, pady=10, fill="both", expand=True)
        self.tree = ttk.Treeview(table_frame, show="headings")
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        # Configure a tag for overrun rows.
        self.tree.tag_configure("overrun", background="red")

        # Buttons frame for Gantt chart and saving changes.
        btn_frame = ctk.CTkFrame(self)
        btn_frame.pack(padx=10, pady=10, fill="x")
        gantt_btn = ctk.CTkButton(
            btn_frame,
            text="View Delayed Gantt Chart",
            command=self.view_delayed_gantt_chart,
        )
        gantt_btn.pack(side="left", padx=5, pady=5)
        save_btn = ctk.CTkButton(
            btn_frame, text="Save Changes", command=self.save_schedule_changes
        )
        save_btn.pack(side="left", padx=5, pady=5)

    def load_schedule(self):
        option = self.schedule_option.get()
        prefix = "LtoR_" if option == "LtoR" else "RtoL_"
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        pattern = os.path.join(data_folder, f"{prefix}*.json")
        files = glob.glob(pattern)
        if not files:
            messagebox.showinfo("Info", f"No schedule files found with prefix {prefix}")
            return
        latest_file = max(files, key=os.path.getmtime)
        self.loaded_schedule_file = latest_file  # Store the file path for later saving.
        try:
            df = pd.read_json(latest_file, orient="records")
            self.schedule_data = df.copy()
            # Preserve the original schedule (pre-delay).
            self.original_schedule = self.schedule_data.copy()
            messagebox.showinfo(
                "Success", f"Loaded schedule: {os.path.basename(latest_file)}"
            )
        except Exception as e:
            messagebox.showerror("Error", f"Error loading schedule: {str(e)}")

    def load_partlist(self):
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        pattern = os.path.join(data_folder, "l3_*.json")
        files = glob.glob(pattern)
        if not files:
            messagebox.showinfo("Info", "No part list files found.")
            return
        latest_file = max(files, key=os.path.getmtime)
        try:
            df = pd.read_json(latest_file, orient="records")
            self.part_list = df.copy()
            if "POST HTZ" in self.part_list.columns:
                parts = self.part_list["POST HTZ"].tolist()
                unique_parts = list(dict.fromkeys(parts))
                self.part_option.configure(values=unique_parts)
                if unique_parts:
                    self.part_option.set(unique_parts[0])
            else:
                messagebox.showerror("Error", "Part list does not contain 'POST HTZ'.")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading part list: {str(e)}")

    def apply_delay(self):
        if self.schedule_data is None:
            messagebox.showwarning("Warning", "Please load a schedule first.")
            return
        selected_part = self.part_option.get()
        try:
            delay_weeks = int(self.delay_entry.get())
        except ValueError:
            messagebox.showerror(
                "Error", "Invalid delay value. Please enter an integer number of weeks."
            )
            return
        phase = self.phase_var.get()  # "Check" or "Release"

        df = self.schedule_data.copy()
        part_row = df[df["Part Number"] == selected_part]
        if part_row.empty:
            messagebox.showerror("Error", "Selected part not found in schedule.")
            return

        selected_cascade_str = str(part_row.iloc[0]["Cascade Level"])

        def cascade_to_list(cascade_str):
            try:
                return list(map(int, cascade_str.split(".")))
            except Exception:
                return []

        selected_cascade = cascade_to_list(selected_cascade_str)
        if not selected_cascade:
            affected = df[df["Part Number"] == selected_part]
        else:

            def is_related(row_cascade_str, selected):
                row_cascade = cascade_to_list(row_cascade_str)
                min_len = min(len(row_cascade), len(selected))
                return row_cascade[:min_len] == selected[:min_len]

            affected = df[
                df["Cascade Level"].apply(
                    lambda cs: is_related(str(cs), selected_cascade)
                )
            ]
        if affected.empty:
            messagebox.showinfo(
                "Info", "No affected parts found for the selected cascade."
            )
            return

        def add_delay(week_str, delay):
            try:
                year, week = map(int, week_str.split("-"))
                dt = datetime.fromisocalendar(year, week, 1)
                dt_delayed = dt + timedelta(weeks=delay)
                iso_year, iso_week, _ = dt_delayed.isocalendar()
                return f"{iso_year}-{iso_week:02d}"
            except Exception:
                return week_str

        def update_row(row):
            if row["Part Number"] == selected_part:
                if phase == "Release":
                    if "Release Start" in row:
                        row["Release Start"] = add_delay(
                            row["Release Start"], delay_weeks
                        )
                    if "Release End" in row:
                        row["Release End"] = add_delay(row["Release End"], delay_weeks)
                else:
                    if "Check Start" in row:
                        row["Check Start"] = add_delay(row["Check Start"], delay_weeks)
                    if "Check End" in row:
                        row["Check End"] = add_delay(row["Check End"], delay_weeks)
                    if "Release Start" in row:
                        row["Release Start"] = add_delay(
                            row["Release Start"], delay_weeks
                        )
                    if "Release End" in row:
                        row["Release End"] = add_delay(row["Release End"], delay_weeks)
            else:
                if "Check Start" in row:
                    row["Check Start"] = add_delay(row["Check Start"], delay_weeks)
                if "Check End" in row:
                    row["Check End"] = add_delay(row["Check End"], delay_weeks)
                if "Release Start" in row:
                    row["Release Start"] = add_delay(row["Release Start"], delay_weeks)
                if "Release End" in row:
                    row["Release End"] = add_delay(row["Release End"], delay_weeks)
            return row

        delayed = affected.apply(update_row, axis=1)
        self.delayed_schedule = delayed.copy()
        self.delayed_schedule = self._enforce_capacity(
            self.delayed_schedule.copy(), CAPACITY_CHECK, CAPACITY_RELEASE
        )
        self.update_table(self.delayed_schedule)

    def _enforce_capacity(self, df, capacity_check, capacity_release):
        def iso_to_date(iso_str):
            try:
                year, week = map(int, iso_str.split("-"))
                return datetime.fromisocalendar(year, week, 1)
            except Exception:
                return None

        df["Check_Start_Date"] = df["Check Start"].apply(iso_to_date)
        df["Release_Start_Date"] = df["Release Start"].apply(iso_to_date)
        iteration = 0
        max_iterations = 10
        while iteration < max_iterations:
            weekly_check = {}
            weekly_release = {}
            for idx, row in df.iterrows():
                if row["Check_Start_Date"] is None or row["Release_Start_Date"] is None:
                    continue
                key_c = row["Check_Start_Date"].strftime("%Y-%W")
                key_r = row["Release_Start_Date"].strftime("%Y-%W")
                comp = row["Component Type"]
                req_check = DEFAULT_EFFORTS.get(comp, {"Check": 5})["Check"]
                req_release = DEFAULT_EFFORTS.get(comp, {"Release": 3})["Release"]
                weekly_check[key_c] = weekly_check.get(key_c, 0) + req_check
                weekly_release[key_r] = weekly_release.get(key_r, 0) + req_release
            over_capacity = False
            for idx, row in df.iterrows():
                if row["Check_Start_Date"] is None or row["Release_Start_Date"] is None:
                    continue
                key_c = row["Check_Start_Date"].strftime("%Y-%W")
                key_r = row["Release_Start_Date"].strftime("%Y-%W")
                comp = row["Component Type"]
                req_check = DEFAULT_EFFORTS.get(comp, {"Check": 5})["Check"]
                req_release = DEFAULT_EFFORTS.get(comp, {"Release": 3})["Release"]
                if (
                    weekly_check.get(key_c, 0) > capacity_check
                    or weekly_release.get(key_r, 0) > capacity_release
                ):
                    new_check_date = row["Check_Start_Date"] + timedelta(weeks=1)
                    new_release_date = row["Release_Start_Date"] + timedelta(weeks=1)
                    df.at[idx, "Check_Start_Date"] = new_check_date
                    df.at[idx, "Release_Start_Date"] = new_release_date
                    df.at[idx, "Check Start"] = (
                        f"{new_check_date.isocalendar()[0]}-{new_check_date.isocalendar()[1]:02d}"
                    )
                    df.at[idx, "Release Start"] = (
                        f"{new_release_date.isocalendar()[0]}-{new_release_date.isocalendar()[1]:02d}"
                    )
                    over_capacity = True
            if not over_capacity:
                break
            iteration += 1
        return df

    def update_table(self, df):
        display_df = df.copy()
        for col in ["Check_Start_Date", "Release_Start_Date"]:
            if col in display_df.columns:
                display_df = display_df.drop(columns=[col])
        for item in self.tree.get_children():
            self.tree.delete(item)
        cols = list(display_df.columns)
        self.tree["columns"] = cols
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
        is_rtol = self.schedule_option.get() == "RtoL" and "Deadline" in cols

        def iso_to_tuple(iso_str):
            try:
                year, week = map(int, iso_str.split("-"))
                return (year, week)
            except Exception:
                return (0, 0)

        for _, row in display_df.iterrows():
            tags = ()
            if is_rtol:
                rel_tuple = iso_to_tuple(row.get("Release End", "0-00"))
                deadline_tuple = iso_to_tuple(row.get("Deadline", "0-00"))
                if rel_tuple > deadline_tuple:
                    tags = ("overrun",)
            self.tree.insert("", "end", values=[row[col] for col in cols], tags=tags)

    def view_delayed_gantt_chart(self):
        if self.delayed_schedule is None or self.delayed_schedule.empty:
            messagebox.showwarning("Warning", "No delayed schedule data available.")
            return
        try:
            if self.original_schedule is None:
                self.original_schedule = self.schedule_data.copy()
            affected_parts = self.delayed_schedule["Part Number"].unique().tolist()
            original_affected = self.original_schedule[
                self.original_schedule["Part Number"].isin(affected_parts)
            ]
            gantt_chart.generate_gantt_chart(
                self.delayed_schedule, "", original_schedule=original_affected
            )
        except Exception as e:
            messagebox.showerror(
                "Error", f"Error displaying delayed Gantt chart: {str(e)}"
            )

    def save_schedule_changes(self):
        """
        Update the affected items in the loaded schedule with the changes
        from the delayed schedule, and then overwrite the original file.
        """
        if self.delayed_schedule is None or self.delayed_schedule.empty:
            messagebox.showwarning("Warning", "No changes to save.")
            return
        # Create a copy of the delayed schedule and drop extra computed columns.
        delayed_cleaned = self.delayed_schedule.copy()
        for extra in ["Check_Start_Date", "Release_Start_Date"]:
            if extra in delayed_cleaned.columns:
                delayed_cleaned = delayed_cleaned.drop(columns=[extra])

        # Define the columns that should be updated.
        changed_columns = ["Check Start", "Check End", "Release Start", "Release End"]

        # For each row in the cleaned delayed schedule, update the matching rows in schedule_data.
        for _, row in delayed_cleaned.iterrows():
            part = row["Part Number"]
            # Update matching rows for the specified columns.
            for col in changed_columns:
                self.schedule_data.loc[
                    self.schedule_data["Part Number"] == part, col
                ] = row[col]

        # Overwrite the originally loaded file.
        if self.loaded_schedule_file is None:
            option = self.schedule_option.get()
            prefix = "LtoR" if option == "LtoR" else "RtoL"
            data_folder = os.path.join(os.path.dirname(__file__), "data")
            self.loaded_schedule_file = os.path.join(
                data_folder, f"{prefix}_default.json"
            )
        try:
            self.schedule_data.to_json(
                self.loaded_schedule_file, orient="records", date_format="iso"
            )
            messagebox.showinfo(
                "Success", "Plan updated successfully in the existing file."
            )
        except Exception as e:
            messagebox.showerror("Error", f"Error saving changes: {e}")
