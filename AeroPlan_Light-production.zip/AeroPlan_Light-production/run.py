import os
import subprocess
import sys
import platform

# Ensure the working directory is the script's directory
os.chdir(os.path.dirname(os.path.abspath(__file__)))


def main():
    """Launch AeroPlan Light using the virtual environment"""
    # Get the base directory and virtual environment paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # Define the Python executable from the virtual environment
    if platform.system() == "Windows":
        python_path = os.path.join(base_dir, ".venv", "Scripts", "python.exe")
    else:
        python_path = os.path.join(base_dir, ".venv", "bin", "python")

    # If the current interpreter is not the one from the virtual environment, re-launch using it.
    if os.path.abspath(sys.executable) != os.path.abspath(python_path):
        print(f"Re-launching run.py using virtual environment python: {python_path}")
        subprocess.run([python_path] + sys.argv)
        sys.exit()

    # Check if the virtual environment exists
    if not os.path.exists(python_path):
        print("ERROR: Virtual environment not found!")
        print("Please run 'install.py' first to set up AeroPlan Light™")
        input("\nPress Enter to exit...")
        return

    # Launch the application
    try:
        # Use sys.executable here since it should match the venv's python at this point
        subprocess.run([sys.executable, "main.py"])
    except Exception as e:
        print(f"ERROR: Failed to launch application: {e}")
        print("\nPlease try running 'install.py' again to fix the installation")
        input("\nPress Enter to exit...")


if __name__ == "__main__":
    main()
