import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime
import pandas as pd
import glob
import os
import json
from gantt_chart import generate_gantt_chart
from fte_curve import generate_fte_curve


class ScheduleLtoRTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.parts_df = None  # Loaded part list DataFrame
        self.schedule_data = None  # Generated schedule DataFrame
        self.plant_deadlines = {}  # Plant deadlines as datetime objects
        self.default_efforts = {
            "Single Part": {"Check": 5, "Release": 3},
            "Sub-Assembly": {"Check": 6, "Release": 4},
            "Assembly": {"Check": 11, "Release": 5},
            "Design Solution": {"Check": 11, "Release": 5},
        }
        self.current_efforts = self.default_efforts.copy()
        self.parent_schedule_map = {}  # Mapping from cascade string to scheduled entry
        self.setup_ui()  # Build UI widgets
        self.refresh_plants()  # Load plant deadlines
        # Attempt to load the latest saved LtoR schedule
        loaded = self.load_latest_schedule("LtoR_")
        if loaded is not None:
            self.schedule_data = loaded.copy()
            self.update_schedule_view()

    def load_latest_schedule(self, prefix):
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        pattern = os.path.join(data_folder, f"{prefix}*.json")
        files = glob.glob(pattern)
        if not files:
            # Informing the user is optional here.
            # messagebox.showinfo("Info", f"No schedule files found with prefix {prefix}")
            return None
        latest_file = max(files, key=os.path.getmtime)
        try:
            df = pd.read_json(latest_file, orient="records")
            return df
        except Exception as e:
            messagebox.showerror("Error", f"Error loading schedule: {e}")
            return None

    def setup_ui(self):
        # Settings Row: Efforts, FTE, Start Date, Plant Dates
        settings_frame = ctk.CTkFrame(self)
        settings_frame.pack(padx=10, pady=5, fill="x")

        # --- Efforts Section ---
        efforts_frame = ctk.CTkFrame(settings_frame, width=300, height=220)
        efforts_frame.pack(side="left", padx=10, pady=5)
        efforts_frame.pack_propagate(False)
        ctk.CTkLabel(
            efforts_frame, text="LtoR Effort (hrs)", font=("Arial", 12, "bold")
        ).pack(padx=10, pady=10)
        self.ltor_effort_inputs = {}
        for comp_type, efforts in self.default_efforts.items():
            frame = ctk.CTkFrame(efforts_frame)
            frame.pack(padx=5, pady=5, fill="x")
            ctk.CTkLabel(frame, text=comp_type, width=100).pack(side="left")
            check_var = tk.StringVar(value=str(efforts["Check"]))
            check_entry = ctk.CTkEntry(frame, textvariable=check_var, width=60)
            check_entry.pack(side="left", padx=5)
            release_var = tk.StringVar(value=str(efforts["Release"]))
            release_entry = ctk.CTkEntry(frame, textvariable=release_var, width=60)
            release_entry.pack(side="left", padx=5)
            self.ltor_effort_inputs[comp_type] = {
                "Check": check_var,
                "Release": release_var,
            }

        # --- FTE Section ---
        fte_frame = ctk.CTkFrame(settings_frame, width=300, height=220)
        fte_frame.pack(side="left", padx=10, pady=5)
        fte_frame.pack_propagate(False)
        ctk.CTkLabel(
            fte_frame, text="LtoR FTE (35hrs/week)", font=("Arial", 12, "bold")
        ).pack(padx=10, pady=10)
        fte_input_frame = ctk.CTkFrame(fte_frame)
        fte_input_frame.pack(padx=10, pady=5, fill="x")
        check_fte_frame = ctk.CTkFrame(fte_input_frame)
        check_fte_frame.pack(side="left", padx=5, pady=5)
        ctk.CTkLabel(check_fte_frame, text="Check FTE").pack(side="top")
        self.ltor_check_fte = ctk.CTkEntry(check_fte_frame, width=100)
        self.ltor_check_fte.pack(side="top", padx=5, pady=5)
        self.ltor_check_fte.insert(0, "1")
        release_fte_frame = ctk.CTkFrame(fte_input_frame)
        release_fte_frame.pack(side="left", padx=5, pady=5)
        ctk.CTkLabel(release_fte_frame, text="Release FTE").pack(side="top")
        self.ltor_release_fte = ctk.CTkEntry(release_fte_frame, width=100)
        self.ltor_release_fte.pack(side="top", padx=5, pady=5)
        self.ltor_release_fte.insert(0, "1")

        # --- Start Date Section ---
        start_date_frame = ctk.CTkFrame(settings_frame, width=300, height=220)
        start_date_frame.pack(side="left", padx=10, pady=5)
        start_date_frame.pack_propagate(False)
        ctk.CTkLabel(
            start_date_frame, text="LtoR Start Date", font=("Arial", 12, "bold")
        ).pack(padx=10, pady=10)
        self.ltor_start_date = ctk.CTkEntry(
            start_date_frame, width=200, placeholder_text="dd.mm.yyyy"
        )
        self.ltor_start_date.pack(padx=5, pady=5)
        today = datetime.now().strftime("%d.%m.%Y")
        self.ltor_start_date.insert(0, today)

        # --- Plant Dates Section ---
        plant_dates_frame = ctk.CTkFrame(settings_frame, width=300, height=220)
        plant_dates_frame.pack(side="left", padx=10, pady=5)
        plant_dates_frame.pack_propagate(False)
        ctk.CTkLabel(
            plant_dates_frame, text="Plant Dates", font=("Arial", 12, "bold")
        ).pack(padx=5, pady=5)
        self.plants_tree = ttk.Treeview(
            plant_dates_frame,
            columns=("Plant", "DFM Date", "DFA Date"),
            show="headings",
            height=5,
        )
        for col in ("Plant", "DFM Date", "DFA Date"):
            self.plants_tree.heading(col, text=col, anchor="center")
            self.plants_tree.column(col, width=100, anchor="center")
        self.plants_tree.pack(side="top", fill="both", expand=True, padx=5, pady=5)
        self.plants_tree.bind("<Double-1>", self.on_cell_double_click)
        refresh_btn = ctk.CTkButton(
            plant_dates_frame, text="Refresh", command=self.refresh_plants
        )
        refresh_btn.pack(padx=5, pady=5)

        # ===== Buttons Section =====
        buttons_frame = ctk.CTkFrame(self)
        buttons_frame.pack(padx=10, pady=5, fill="x")
        ctk.CTkButton(
            buttons_frame, text="Generate LtoR Schedule", command=self.generate_schedule
        ).pack(side="left", padx=10, pady=5)
        ctk.CTkButton(
            buttons_frame, text="View LtoR Gantt Chart", command=self.view_gantt_chart
        ).pack(side="left", padx=10, pady=5)
        ctk.CTkButton(
            buttons_frame, text="View LtoR FTE Curve", command=self.view_fte_curve
        ).pack(side="left", padx=10, pady=5)

        # ===== Schedule Table Section =====
        table_frame = ctk.CTkFrame(self)
        table_frame.pack(padx=10, pady=10, fill="both", expand=True)
        self.schedule_tree = ttk.Treeview(table_frame, show="headings")
        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.schedule_tree.yview
        )
        self.schedule_tree.configure(yscrollcommand=scrollbar.set)
        self.schedule_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.schedule_tree["columns"] = (
            "Part Number",
            "Cascade Level",
            "Component Type",
            "Schedule Info",
        )
        for col in self.schedule_tree["columns"]:
            self.schedule_tree.heading(col, text=col, anchor="center")
            self.schedule_tree.column(col, width=150, anchor="center")
        self.schedule_tree.bind("<Double-1>", self.on_cell_double_click)

    def load_parts(self):
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        json_files = glob.glob(os.path.join(data_folder, "l3_*.json"))
        if not json_files:
            return None
        latest_file = max(json_files, key=os.path.getmtime)
        try:
            parts_df = pd.read_json(latest_file, orient="records")
            return parts_df
        except Exception as e:
            messagebox.showerror("Error", f"Error loading part list: {e}")
            return None

    def refresh_plants(self):
        parts_df = self.load_parts()
        if parts_df is None or parts_df.empty:
            messagebox.showwarning("Warning", "No part list available!")
            return
        self.parts_df = parts_df.copy()
        if "Responsible Plant" not in self.parts_df.columns:
            messagebox.showerror(
                "Error", "Part list does not contain 'Responsible Plant'."
            )
            return
        plants = self.parts_df["Responsible Plant"].dropna().unique()
        plants = [p for p in plants if str(p).strip() != ""]
        plants.sort()
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        plants_file = os.path.join(data_folder, "plants.json")
        saved_dates = {}
        if os.path.exists(plants_file):
            try:
                with open(plants_file, "r") as f:
                    data = json.load(f)
                    for entry in data:
                        saved_dates[entry["Plant"]] = {
                            "DFM": entry.get("DFM", ""),
                            "DFA": entry.get("DFA", ""),
                        }
            except Exception as e:
                messagebox.showerror("Error", f"Error loading plants file: {e}")
        for item in self.plants_tree.get_children():
            self.plants_tree.delete(item)
        self.plant_deadlines = {}
        for plant in plants:
            dfm = saved_dates.get(plant, {}).get("DFM", "")
            dfa = saved_dates.get(plant, {}).get("DFA", "")
            self.plants_tree.insert("", "end", values=(plant, dfm, dfa))
            try:
                dfm_date = (
                    datetime.strptime(dfm, "%d.%m.%Y") if dfm.strip() != "" else None
                )
            except Exception:
                dfm_date = None
            try:
                dfa_date = (
                    datetime.strptime(dfa, "%d.%m.%Y") if dfa.strip() != "" else None
                )
            except Exception:
                dfa_date = None
            self.plant_deadlines[plant] = {"DFM": dfm_date, "DFA": dfa_date}

    def on_cell_double_click(self, event):
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        column = self.tree.identify_column(event.x)
        rowid = self.tree.identify_row(event.y)
        if not rowid:
            return
        x, y, width, height = self.tree.bbox(rowid, column)
        col_index = int(column.replace("#", "")) - 1
        current_value = self.tree.item(rowid, "values")[col_index]
        entry = tk.Entry(self.tree)
        entry.place(x=x, y=y, width=width, height=height)
        entry.insert(0, current_value)
        entry.focus_set()

        def on_enter(event):
            new_val = entry.get()
            values = list(self.tree.item(rowid, "values"))
            values[col_index] = new_val
            self.tree.item(rowid, values=values)
            # Update underlying schedule_data (assuming tree order corresponds to DataFrame order)
            row_ids = list(self.schedule_tree.get_children())
            df_index = row_ids.index(rowid)
            col_name = self.schedule_tree["columns"][col_index]
            self.schedule_data.at[df_index, col_name] = new_val
            entry.destroy()

        entry.bind("<Return>", on_enter)
        entry.bind("<FocusOut>", lambda e: entry.destroy())

    def generate_schedule(self):
        parts_df = self.load_parts()
        if parts_df is None or parts_df.empty:
            messagebox.showwarning("Warning", "No part list available for scheduling!")
            return
        self.parts_df = parts_df.copy()
        if "Cascade Level" not in self.parts_df.columns:
            self.parts_df["Cascade Level"] = ""
        self.parts_df["Depth"] = self.parts_df["Cascade Level"].apply(
            lambda x: len(x.split(".")) if x else 0
        )
        try:
            start_date = datetime.strptime(self.ltor_start_date.get(), "%d.%m.%Y")
        except ValueError:
            messagebox.showerror(
                "Error", "Invalid LtoR start date format. Use dd.mm.yyyy."
            )
            return
        try:
            capacity_release = float(self.ltor_release_fte.get()) * 35
            capacity_check = float(self.ltor_check_fte.get()) * 35
        except ValueError:
            messagebox.showerror("Error", "Invalid FTE inputs.")
            return
        weekly_release_usage = {}
        weekly_check_usage = {}
        schedule = {}
        self.parent_schedule_map = {}
        sorted_parts = self.parts_df.sort_values(by="Depth", ascending=False)
        for idx, part in sorted_parts.iterrows():
            cascade = part["Cascade Level"].strip()
            comp_type = part.get("Component Type", "Single Part")
            req_check = self.current_efforts.get(comp_type, {"Check": 5})["Check"]
            req_release = self.current_efforts.get(comp_type, {"Release": 3})["Release"]
            if cascade != "":
                children_weeks = [
                    sched["release_week"]
                    for sched in schedule.values()
                    if sched["cascade"].startswith(cascade + ".")
                ]
                if children_weeks:
                    earliest_release = max(children_weeks) + 1
                else:
                    earliest_release = 2
            else:
                earliest_release = 2
            candidate_release = max(earliest_release, 2)
            while True:
                candidate_check = candidate_release - 1
                used_release = weekly_release_usage.get(candidate_release, 0)
                used_check = weekly_check_usage.get(candidate_check, 0)
                if (
                    used_release + req_release <= capacity_release
                    and used_check + req_check <= capacity_check
                ):
                    schedule[idx] = {
                        "release_week": candidate_release,
                        "check_week": candidate_check,
                        "cascade": cascade,
                        "Part Number": part.get("POST HTZ", ""),
                        "Component Type": comp_type,
                    }
                    weekly_release_usage[candidate_release] = used_release + req_release
                    weekly_check_usage[candidate_check] = used_check + req_check
                    break
                candidate_release += 1
        sched_entries = []
        for sch in schedule.values():
            check_date = start_date + pd.Timedelta(weeks=sch["check_week"] - 1)
            release_date = start_date + pd.Timedelta(weeks=sch["release_week"] - 1)
            iso_year_c, iso_week_c, _ = check_date.isocalendar()
            iso_year_r, iso_week_r, _ = release_date.isocalendar()
            sched_entries.append(
                {
                    "Part Number": sch["Part Number"],
                    "Cascade Level": sch["cascade"],
                    "Component Type": sch["Component Type"],
                    "Check Start": f"{iso_year_c}-{iso_week_c:02d}",
                    "Check End": f"{iso_year_c}-{iso_week_c:02d}",
                    "Release Start": f"{iso_year_r}-{iso_week_r:02d}",
                    "Release End": f"{iso_year_r}-{iso_week_r:02d}",
                }
            )
        self.schedule_data = pd.DataFrame(sched_entries)
        for item in self.schedule_tree.get_children():
            self.schedule_tree.delete(item)
        self.schedule_tree["columns"] = tuple(self.schedule_data.columns)
        for col in self.schedule_tree["columns"]:
            self.schedule_tree.heading(col, text=col, anchor="center")
            self.schedule_tree.column(col, width=120, anchor="center")
        for _, row in self.schedule_data.iterrows():
            vals = [str(val) for val in row]
            self.schedule_tree.insert("", "end", values=vals)
        messagebox.showinfo("Success", "LtoR schedule generated successfully!")
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        timestamp = datetime.now().strftime("%d%m%Y%H%M")
        filename = f"LtoR_{timestamp}.json"
        filepath = os.path.join(data_folder, filename)
        try:
            self.schedule_data.to_json(filepath, orient="records", date_format="iso")
            messagebox.showinfo("Success", f"Schedule saved as JSON: {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving schedule JSON: {e}")

    def update_schedule_view(self):
        for item in self.schedule_tree.get_children():
            self.schedule_tree.delete(item)
        if self.schedule_data is not None and not self.schedule_data.empty:
            cols = list(self.schedule_data.columns)
            self.schedule_tree["columns"] = cols
            for col in cols:
                self.schedule_tree.heading(col, text=col, anchor="center")
                self.schedule_tree.column(col, width=120, anchor="center")
            for _, row in self.schedule_data.iterrows():
                self.schedule_tree.insert("", "end", values=[row[col] for col in cols])

    def view_gantt_chart(self):
        try:
            generate_gantt_chart(self.schedule_data, self.ltor_start_date.get())
        except Exception as e:
            messagebox.showerror("Error", f"Error displaying Gantt chart: {e}")

    def view_fte_curve(self):
        try:
            generate_fte_curve(self.schedule_data, self.current_efforts)
        except Exception as e:
            messagebox.showerror("Error", f"Error displaying FTE curve: {e}")
