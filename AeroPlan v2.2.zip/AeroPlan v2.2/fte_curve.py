import pandas as pd
import plotly.express as px


def generate_fte_curve(schedule_data, current_efforts):
    """
    Generate and display a Plotly line chart of the FTE curve.

    schedule_data: a DataFrame that must contain the following columns:
      - "Check Start"    (ISO week string, e.g., "2025-07")
      - "Release Start"  (ISO week string, e.g., "2025-08")
      - "Component Type" (e.g., "Single Part", "Assembly", etc.)

    current_efforts: a dictionary mapping component types to their effort values,
      for example:
          {
              "Single Part": {"Check": 5, "Release": 3},
              "Sub-Assembly": {"Check": 6, "Release": 4},
              "Assembly": {"Check": 11, "Release": 5},
              "Design Solution": {"Check": 11, "Release": 5},
          }

    The function aggregates the required hours per week (for Check and Release), converts
    them to FTE (by dividing by 35), and displays a line chart with week labels (YYYY-XX)
    on the X-axis.
    """
    # Initialize dictionaries to accumulate effort (in hours) per week.
    weekly_check = {}
    weekly_release = {}

    # Iterate over each row of the schedule data.
    for _, row in schedule_data.iterrows():
        week_check = row["Check Start"]
        week_release = row["Release Start"]
        comp_type = row["Component Type"]
        # Retrieve the effort values for this component type.
        efforts = current_efforts.get(comp_type, {"Check": 5, "Release": 3})
        weekly_check[week_check] = weekly_check.get(week_check, 0) + efforts["Check"]
        weekly_release[week_release] = (
            weekly_release.get(week_release, 0) + efforts["Release"]
        )

    # Combine all week labels and sort them.
    all_weeks = sorted(
        set(list(weekly_check.keys()) + list(weekly_release.keys())),
        key=lambda w: (int(w.split("-")[0]), int(w.split("-")[1])),
    )

    # Convert hours to FTE by dividing by 35.
    check_fte = [weekly_check.get(week, 0) / 35 for week in all_weeks]
    release_fte = [weekly_release.get(week, 0) / 35 for week in all_weeks]

    # Build a DataFrame for plotting.
    df_curve = pd.DataFrame(
        {"Week": all_weeks, "Check FTE": check_fte, "Release FTE": release_fte}
    )
    df_melt = df_curve.melt(
        id_vars="Week",
        value_vars=["Check FTE", "Release FTE"],
        var_name="Phase",
        value_name="FTE",
    )

    # Create a line chart using Plotly Express.
    fig = px.line(
        df_melt, x="Week", y="FTE", color="Phase", markers=True, title="FTE Curve"
    )
    fig.update_xaxes(title="Week (YYYY-XX)", type="category")
    fig.update_yaxes(title="FTE")
    fig.update_layout(template="plotly_white")
    fig.show()
