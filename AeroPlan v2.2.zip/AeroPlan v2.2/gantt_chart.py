from datetime import datetime, timedelta
import plotly.graph_objects as go


def generate_gantt_chart(schedule_data, original_schedule=None):
    """
    Generate and display a Gantt chart that shows both original and delayed dates,
    including red arrows to indicate shifts.

    Parameters:
      - schedule_data: DataFrame with the (possibly delayed) schedule.
         Required columns: "Part Number", "Check Start", "Release Start", etc.
      - original_schedule (optional): DataFrame with the original schedule.
         If provided, only affected parts should be included so that the chart
         shows a comparison between original and delayed dates.

    The function draws:
      - For each part, the original Check and Release phases as dashed light gray bars.
      - The delayed phases as solid blue (Check) and green (Release) bars.
      - Red arrows from the original to the delayed start dates if there is a shift.
    """

    # If no original schedule is provided, use schedule_data as original.
    if original_schedule is None:
        original_schedule = schedule_data.copy()

    # Normalize and sort the original schedule by a chosen key (e.g. Cascade Level).
    orig = original_schedule.copy()
    orig.columns = [col.replace(" ", "_") for col in orig.columns]
    # Here we sort by "Cascade_Level" (change if needed) to keep a meaningful order.
    # REMOVED: orig = orig.sort_values(by="Release_Start_Date", ascending=True).reset_index(drop=True)

    # Build a lookup for delayed data by Part Number.
    delayed_lookup = {}
    delayed = schedule_data.copy()
    delayed.columns = [col.replace(" ", "_") for col in delayed.columns]
    for _, row in delayed.iterrows():
        part = row["Part_Number"]
        delayed_lookup[part] = row

    # Helper: Convert an ISO week string "YYYY-XX" to a date (Monday of that week)
    def iso_to_date(iso_str):
        try:
            year, week = map(int, iso_str.split("-"))
            return datetime.fromisocalendar(year, week, 1)
        except Exception as e:
            raise ValueError(f"Error converting '{iso_str}' to date: {e}")

    # Compute original dates.
    orig["Check_Start_Date"] = orig["Check_Start"].apply(iso_to_date)
    orig["Release_Start_Date"] = orig["Release_Start"].apply(iso_to_date)

    # Sort by the calculated Release_Start_Date (ascending)
    orig = orig.sort_values(by="Release_Start_Date", ascending=True).reset_index(drop=True)

    # For delayed data, compute dates.
    for part, row in delayed_lookup.items():
        delayed_lookup[part]["Check_Start_Date"] = iso_to_date(row["Check_Start"])
        delayed_lookup[part]["Release_Start_Date"] = iso_to_date(row["Release_Start"])

    # --- Updated x-axis range calculation ---
    # Force x-axis to start at the earliest original Check Start.
    min_date = orig["Check_Start_Date"].min()
    orig_max = (orig["Release_Start_Date"] + timedelta(days=7)).max()
    if delayed_lookup:
        delayed_dates = [r["Release_Start_Date"] for r in delayed_lookup.values()]
        delayed_max = (
            max([dt + timedelta(days=7) for dt in delayed_dates])
            if delayed_dates
            else orig_max
        )
        max_date = max(orig_max, delayed_max)
    else:
        max_date = orig_max
    # --- End updated x-axis range ---

    fig = go.Figure()
    bar_thickness = 0.15  # vertical half-height for each bar

    # Loop over each part in the original (filtered) schedule order.
    for i, row in orig.iterrows():
        part = row["Part_Number"]
        # Original phase dates.
        o_check_start = row["Check_Start_Date"]
        o_release_start = row["Release_Start_Date"]
        o_check_end = o_check_start + timedelta(days=7)
        o_release_end = o_release_start + timedelta(days=7)

        # Check if a delayed version exists.
        if part in delayed_lookup:
            d_row = delayed_lookup[part]
            d_check_start = d_row["Check_Start_Date"]
            d_release_start = d_row["Release_Start_Date"]
            d_check_end = d_check_start + timedelta(days=7)
            d_release_end = d_release_start + timedelta(days=7)
            # Draw original (dashed) bars.
            fig.add_shape(
                type="rect",
                x0=o_check_start,
                x1=o_check_end,
                y0=i - bar_thickness * 2,
                y1=i - bar_thickness,
                fillcolor="lightgray",
                opacity=0.5,
                line=dict(dash="dash", width=1),
            )
            fig.add_shape(
                type="rect",
                x0=o_release_start,
                x1=o_release_end,
                y0=i + bar_thickness,
                y1=i + bar_thickness * 2,
                fillcolor="lightgray",
                opacity=0.5,
                line=dict(dash="dash", width=1),
            )
            # Draw delayed (solid) bars.
            fig.add_shape(
                type="rect",
                x0=d_check_start,
                x1=d_check_end,
                y0=i - bar_thickness * 2,
                y1=i - bar_thickness,
                fillcolor="blue",
                opacity=0.8,
                line=dict(width=0),
            )
            fig.add_shape(
                type="rect",
                x0=d_release_start,
                x1=d_release_end,
                y0=i + bar_thickness,
                y1=i + bar_thickness * 2,
                fillcolor="green",
                opacity=0.8,
                line=dict(width=0),
            )
            # Draw red arrows to indicate the shift if there is a difference.
            if d_check_start != o_check_start:
                fig.add_annotation(
                    x=d_check_start,
                    y=i - bar_thickness * 1.5,
                    ax=o_check_start,
                    ay=i - bar_thickness * 1.5,
                    xref="x",
                    yref="y",
                    axref="x",
                    ayref="y",
                    showarrow=True,
                    arrowhead=3,
                    arrowsize=1.5,
                    arrowwidth=2,
                    arrowcolor="red",
                )
            if d_release_start != o_release_start:
                fig.add_annotation(
                    x=d_release_start,
                    y=i + bar_thickness * 1.5,
                    ax=o_release_start,
                    ay=i + bar_thickness * 1.5,
                    xref="x",
                    yref="y",
                    axref="x",
                    ayref="y",
                    showarrow=True,
                    arrowhead=3,
                    arrowsize=1.5,
                    arrowwidth=2,
                    arrowcolor="red",
                )
        else:
            # Not affected; draw only the original (solid) bars.
            fig.add_shape(
                type="rect",
                x0=o_check_start,
                x1=o_check_end,
                y0=i - bar_thickness * 2,
                y1=i - bar_thickness,
                fillcolor="blue",
                opacity=0.8,
                line=dict(width=0),
            )
            fig.add_shape(
                type="rect",
                x0=o_release_start,
                x1=o_release_end,
                y0=i + bar_thickness,
                y1=i + bar_thickness * 2,
                fillcolor="green",
                opacity=0.8,
                line=dict(width=0),
            )

        # Annotation with part number.
        fig.add_annotation(
            x=o_check_start + (o_check_end - o_check_start) / 2,
            y=i,
            text=str(part),
            showarrow=False,
            font=dict(color="white", size=10),
        )

    # Set up the y-axis with the complete list of parts.
    fig.update_yaxes(
        tickvals=list(range(len(orig))),
        ticktext=orig["Part_Number"].tolist(),
        range=[len(orig) - 0.5, -0.5],
        title="Part Number",
        autorange=False,
    )
    # Set up the x-axis using the overall date range.
    fig.update_xaxes(
        title="Calendar Weeks",
        type="date",
        range=[min_date, max_date],
        tickformat="%Y-W%W",
    )
    fig.update_layout(
        title="Gantt Chart with Delay Shift",
        template="plotly_white",
        margin=dict(l=150, r=50, t=70, b=50),
        height=200 + 30 * len(orig),
    )

    fig.show()
