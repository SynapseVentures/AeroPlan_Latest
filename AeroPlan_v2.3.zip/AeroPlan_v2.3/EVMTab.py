import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk, filedialog
import json
import os
import pandas as pd
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Image,
    Paragraph,
    Spacer,
)
from reportlab.lib.styles import ParagraphStyle


class EVMTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.evm_data = {"projects": []}
        self.data_file = os.path.join(
            os.path.dirname(__file__), "data", "evm_data.json"
        )
        self.current_project = None
        self.current_category = None
        self.months = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
        ]
        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        # Top frame: Project and Category selection and creation
        top_frame = ctk.CTkFrame(self)
        top_frame.pack(padx=10, pady=5, fill="x")

        ctk.CTkLabel(top_frame, text="Project:").grid(
            row=0, column=0, padx=5, pady=5, sticky="w"
        )
        self.project_var = tk.StringVar()
        self.project_menu = ctk.CTkOptionMenu(
            top_frame,
            variable=self.project_var,
            values=[],
            command=self.on_project_change,
        )
        self.project_menu.grid(row=0, column=1, padx=5, pady=5)
        new_project_btn = ctk.CTkButton(
            top_frame, text="New Project", command=self.new_project
        )
        new_project_btn.grid(row=0, column=2, padx=5, pady=5)

        ctk.CTkLabel(top_frame, text="Category:").grid(
            row=1, column=0, padx=5, pady=5, sticky="w"
        )
        self.category_var = tk.StringVar()
        self.category_menu = ctk.CTkOptionMenu(
            top_frame,
            variable=self.category_var,
            values=[],
            command=self.on_category_change,
        )
        self.category_menu.grid(row=1, column=1, padx=5, pady=5)
        new_category_btn = ctk.CTkButton(
            top_frame, text="New Category", command=self.new_category
        )
        new_category_btn.grid(row=1, column=2, padx=5, pady=5)

        # Table frame: displays items (flattened: one row per option per month)
        table_frame = ctk.CTkFrame(self)
        table_frame.pack(padx=10, pady=5, fill="both", expand=True)
        self.tree = ttk.Treeview(table_frame, show="headings")
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.tree["columns"] = ("Option", "Month", "Expected", "Actual")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col, anchor="center")
            self.tree.column(col, width=100, anchor="center")
        self.tree.bind("<Double-1>", self.on_cell_double_click)

        # Totals table: displays monthly totals
        totals_frame = ctk.CTkFrame(self)
        totals_frame.pack(padx=10, pady=5, fill="x")
        ctk.CTkLabel(totals_frame, text="Monthly Totals:").pack(anchor="w", padx=5)
        self.totals_tree = ttk.Treeview(totals_frame, show="headings", height=5)
        self.totals_tree.pack(side="left", fill="x", expand=True)
        totals_scroll = ttk.Scrollbar(
            totals_frame, orient="vertical", command=self.totals_tree.yview
        )
        self.totals_tree.configure(yscrollcommand=totals_scroll.set)
        totals_scroll.pack(side="right", fill="y")
        self.totals_tree["columns"] = ("Month", "Total Expected", "Total Actual")
        for col in self.totals_tree["columns"]:
            self.totals_tree.heading(col, text=col, anchor="center")
            self.totals_tree.column(col, width=120, anchor="center")

        # Bottom buttons: Add Option, Save Data, Export Report
        btn_frame = ctk.CTkFrame(self)
        btn_frame.pack(padx=10, pady=5, fill="x")
        add_option_btn = ctk.CTkButton(
            btn_frame, text="Add Option", command=self.add_option
        )
        add_option_btn.pack(side="left", padx=5, pady=5)
        save_btn = ctk.CTkButton(btn_frame, text="Save Data", command=self.save_data)
        save_btn.pack(side="left", padx=5, pady=5)
        export_btn = ctk.CTkButton(
            btn_frame, text="Export Report", command=self.export_report
        )
        export_btn.pack(side="left", padx=5, pady=5)

    def new_project(self):
        project_name = simpledialog.askstring("New Project", "Enter project name:")
        if project_name:
            if not any(
                proj["name"] == project_name for proj in self.evm_data["projects"]
            ):
                self.evm_data["projects"].append(
                    {"name": project_name, "categories": []}
                )
                self.current_project = project_name
                self.update_project_menu()
            else:
                messagebox.showwarning("Warning", "Project already exists.")

    def new_category(self):
        if not self.project_var.get():
            messagebox.showwarning("Warning", "Select or create a project first.")
            return
        category_name = simpledialog.askstring("New Category", "Enter category name:")
        if category_name:
            project = next(
                (
                    proj
                    for proj in self.evm_data["projects"]
                    if proj["name"] == self.project_var.get()
                ),
                None,
            )
            if project:
                if not any(
                    cat["name"] == category_name for cat in project["categories"]
                ):
                    project["categories"].append({"name": category_name, "items": []})
                    self.current_category = category_name
                    self.update_category_menu(project)
                else:
                    messagebox.showwarning("Warning", "Category already exists.")

    def add_option(self):
        if not self.project_var.get() or not self.category_var.get():
            messagebox.showwarning(
                "Warning", "Select or create a project and category first."
            )
            return
        option_name = simpledialog.askstring("New Option", "Enter option name:")
        if option_name:
            monthly = {month: {"expected": 0, "actual": 0} for month in self.months}
            project = next(
                (
                    proj
                    for proj in self.evm_data["projects"]
                    if proj["name"] == self.project_var.get()
                ),
                None,
            )
            if project:
                category = next(
                    (
                        cat
                        for cat in project["categories"]
                        if cat["name"] == self.category_var.get()
                    ),
                    None,
                )
                if category:
                    category["items"].append(
                        {"option": option_name, "monthly": monthly}
                    )
                    self.update_treeview()

    def update_treeview(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        project = next(
            (
                proj
                for proj in self.evm_data["projects"]
                if proj["name"] == self.project_var.get()
            ),
            None,
        )
        if project is None:
            return
        category = next(
            (
                cat
                for cat in project["categories"]
                if cat["name"] == self.category_var.get()
            ),
            None,
        )
        if category is None:
            return
        for item in category["items"]:
            for month in self.months:
                exp = item["monthly"][month]["expected"]
                act = item["monthly"][month]["actual"]
                self.tree.insert("", "end", values=(item["option"], month, exp, act))
        self.update_totals_view()

    def update_totals_view(self):
        for item in self.totals_tree.get_children():
            self.totals_tree.delete(item)
        totals = {month: {"expected": 0, "actual": 0} for month in self.months}
        project = next(
            (
                proj
                for proj in self.evm_data["projects"]
                if proj["name"] == self.project_var.get()
            ),
            None,
        )
        if project is None:
            return
        category = next(
            (
                cat
                for cat in project["categories"]
                if cat["name"] == self.category_var.get()
            ),
            None,
        )
        if category is None:
            return
        for item in category["items"]:
            for month in self.months:
                try:
                    totals[month]["expected"] += float(
                        item["monthly"][month]["expected"]
                    )
                    totals[month]["actual"] += float(item["monthly"][month]["actual"])
                except Exception:
                    pass
        for month in self.months:
            self.totals_tree.insert(
                "",
                "end",
                values=(month, totals[month]["expected"], totals[month]["actual"]),
            )

    def update_project_menu(self):
        projects = [proj["name"] for proj in self.evm_data["projects"]]
        self.project_menu.configure(values=projects)
        if projects:
            self.project_var.set(projects[0])
            self.current_project = projects[0]
            project = next(
                (
                    proj
                    for proj in self.evm_data["projects"]
                    if proj["name"] == projects[0]
                ),
                None,
            )
            if project:
                self.update_category_menu(project)
        else:
            self.project_var.set("")
            self.category_menu.configure(values=[])
            for item in self.tree.get_children():
                self.tree.delete(item)
            for item in self.totals_tree.get_children():
                self.totals_tree.delete(item)

    def update_category_menu(self, project):
        categories = [cat["name"] for cat in project["categories"]]
        self.category_menu.configure(values=categories)
        if categories:
            self.category_var.set(categories[0])
            self.current_category = categories[0]
        else:
            self.category_var.set("")
        self.update_treeview()

    def on_project_change(self, selected):
        self.current_project = selected
        project = next(
            (proj for proj in self.evm_data["projects"] if proj["name"] == selected),
            None,
        )
        if project:
            self.update_category_menu(project)
        else:
            self.update_treeview()

    def on_category_change(self, selected):
        self.current_category = selected
        self.update_treeview()

    def on_cell_double_click(self, event):
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        column = self.tree.identify_column(event.x)
        rowid = self.tree.identify_row(event.y)
        if not rowid:
            return
        x, y, width, height = self.tree.bbox(rowid, column)
        col_index = int(column.replace("#", "")) - 1
        current_value = self.tree.item(rowid, "values")[col_index]
        entry = tk.Entry(self.tree)
        entry.place(x=x, y=y, width=width, height=height)
        entry.insert(0, current_value)
        entry.focus_set()

        def on_enter(event):
            new_val = entry.get()
            values = list(self.tree.item(rowid, "values"))
            values[col_index] = new_val
            self.tree.item(rowid, values=values)
            # Update underlying evm_data.
            option, month, _, _ = values
            project = next(
                (
                    proj
                    for proj in self.evm_data["projects"]
                    if proj["name"] == self.project_var.get()
                ),
                None,
            )
            if project:
                category = next(
                    (
                        cat
                        for cat in project["categories"]
                        if cat["name"] == self.category_var.get()
                    ),
                    None,
                )
                if category:
                    for item in category["items"]:
                        if item["option"] == option:
                            col_name = self.tree["columns"][col_index]
                            if col_name == "Expected":
                                item["monthly"][month]["expected"] = new_val
                            elif col_name == "Actual":
                                item["monthly"][month]["actual"] = new_val
            self.update_totals_view()
            entry.destroy()

        entry.bind("<Return>", on_enter)
        entry.bind("<FocusOut>", lambda e: entry.destroy())

    def save_data(self):
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        try:
            with open(self.data_file, "w") as f:
                json.dump(self.evm_data, f, indent=4)
            messagebox.showinfo("Success", "EVM data saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving EVM data: {e}")

    def load_data(self):
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, "r") as f:
                    self.evm_data = json.load(f)
                self.update_project_menu()
            except Exception as e:
                messagebox.showerror("Error", f"Error loading EVM data: {e}")

    def export_report(self):
        project_name = self.project_var.get()
        category_name = self.category_var.get()
        project = next(
            (
                proj
                for proj in self.evm_data["projects"]
                if proj["name"] == project_name
            ),
            None,
        )
        if not project:
            messagebox.showwarning("Warning", "No project selected.")
            return
        category = next(
            (cat for cat in project["categories"] if cat["name"] == category_name), None
        )
        if not category:
            messagebox.showwarning("Warning", "No category selected.")
            return
        # Aggregate monthly totals over all options.
        monthly_totals = {month: {"expected": 0, "actual": 0} for month in self.months}
        for item in category["items"]:
            for month in self.months:
                try:
                    monthly_totals[month]["expected"] += float(
                        item["monthly"][month]["expected"]
                    )
                    monthly_totals[month]["actual"] += float(
                        item["monthly"][month]["actual"]
                    )
                except Exception:
                    pass
        rows = []
        overall_expected = 0
        overall_actual = 0
        for month in self.months:
            exp = monthly_totals[month]["expected"]
            act = monthly_totals[month]["actual"]
            overall_expected += exp
            overall_actual += act
            rows.append({"Month": month, "Expected": exp, "Actual": act})
        df = pd.DataFrame(rows)

        # Generate improved chart using matplotlib.
        plt.style.use("ggplot")
        plt.figure(figsize=(8, 4))
        plt.plot(
            df["Month"],
            df["Expected"],
            marker="o",
            label="Expected",
            color="blue",
            linewidth=2,
        )
        plt.bar(df["Month"], df["Actual"], alpha=0.7, label="Actual", color="orange")
        plt.title(f"EVM Report - {project_name} / {category_name}", fontsize=14)
        plt.xlabel("Month", fontsize=12)
        plt.ylabel("Hours", fontsize=12)
        plt.grid(True, linestyle="--", alpha=0.5)
        plt.legend(fontsize=10)
        plt.tight_layout()
        chart_file = os.path.join(os.path.dirname(__file__), "data", "evm_chart.png")
        plt.savefig(chart_file, bbox_inches="tight")
        plt.close()

        # Create PDF report with ReportLab.
        pdf_file = filedialog.asksaveasfilename(
            defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")]
        )
        if not pdf_file:
            return
        doc = SimpleDocTemplate(
            pdf_file,
            pagesize=letter,
            rightMargin=40,
            leftMargin=40,
            topMargin=60,
            bottomMargin=40,
        )
        elements = []
        # Removed unused 'styles' variable here.
        header_style = ParagraphStyle(
            name="HeaderStyle",
            fontSize=20,
            leading=24,
            alignment=1,  # center alignment
            spaceAfter=20,
        )
        title_text = "AeroPlan Light - EVM Report"
        elements.append(Paragraph(title_text, header_style))
        subtitle_style = ParagraphStyle(
            name="SubtitleStyle", fontSize=14, leading=18, alignment=1, spaceAfter=12
        )
        subtitle_text = f"Project: {project_name} | Category: {category_name}"
        elements.append(Paragraph(subtitle_text, subtitle_style))
        desc_style = ParagraphStyle(
            name="BodyStyle", fontSize=10, leading=12, alignment=1, spaceAfter=20
        )
        desc_text = (
            "This report summarizes the monthly expected and actual hours "
            "for the selected project and category. The curve represents the planned hours, "
            "while the bars indicate the actual hours logged. "
            "Overall Totals: Expected = {:.1f} hrs, Actual = {:.1f} hrs. "
            "This report is intended for corporate performance monitoring and earned value management "
            "analysis."
        ).format(overall_expected, overall_actual)
        elements.append(Paragraph(desc_text, desc_style))
        if os.path.exists(chart_file):
            im = Image(chart_file, width=400, height=200)
            im.hAlign = "CENTER"
            elements.append(im)
            elements.append(Spacer(1, 12))
        table_data = [list(df.columns)]
        for index, row in df.iterrows():
            table_data.append([row["Month"], row["Expected"], row["Actual"]])
        t = Table(table_data, hAlign="CENTER")
        t.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4F81BD")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(t)
        try:
            doc.build(elements)
            messagebox.showinfo("Success", "PDF report exported successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Error exporting PDF: {e}")
