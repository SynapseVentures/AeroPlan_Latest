import customtkinter as ctk
from PartListTab import PartListTab
from ScheduleLtoRTab import ScheduleLtoRTab
from ScheduleRtoLTab import ScheduleRtoLTab
from ClashAnalysisTab import ClashAnalysisTab
from EVMTab import EVMTab
from tkinter import messagebox


class AeroPlanLight(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("AeroPlan Light v2.0")
        self.geometry("1200x800")
        self.create_tabs()
        messagebox.showinfo("Loaded", "Part list and schedules loaded successfully.")

    def create_tabs(self):
        # Use the CTkTabview's built-in command callback.
        self.tabview = ctk.CTkTabview(self, command=self.on_tab_change)
        self.tabview.pack(fill="both", expand=True)

        # Create tabs by name.
        self.tabview.add("Part List")
        self.tabview.add("Schedule LtoR")
        self.tabview.add("Schedule RtoL")
        self.tabview.add("Clash Analysis")
        self.tabview.add("EVM")

        # Retrieve the frame for each tab.
        part_list_frame = self.tabview.tab("Part List")
        schedule_ltor_frame = self.tabview.tab("Schedule LtoR")
        schedule_rtol_frame = self.tabview.tab("Schedule RtoL")
        clash_frame = self.tabview.tab("Clash Analysis")
        evm_frame = self.tabview.tab("EVM")

        # Instantiate your custom tab classes.
        self.partListTab = PartListTab(part_list_frame)
        self.scheduleLtoRTab = ScheduleLtoRTab(schedule_ltor_frame)
        self.scheduleRtoLTab = ScheduleRtoLTab(schedule_rtol_frame)
        self.clashAnalysisTab = ClashAnalysisTab(clash_frame)
        self.evmTab = EVMTab(evm_frame)

    def on_tab_change(self):
        # Retrieve the current tab name from the tabview.
        tab_name = self.tabview.get()
        if tab_name == "Schedule LtoR":
            latest = self.scheduleLtoRTab.load_latest_schedule("LtoR_")
            if latest is not None:
                self.scheduleLtoRTab.schedule_data = latest.copy()
                self.scheduleLtoRTab.update_schedule_view()
        elif tab_name == "Schedule RtoL":
            latest = self.scheduleRtoLTab.load_latest_schedule("RtoL_")
            if latest is not None:
                self.scheduleRtoLTab.schedule_data = latest.copy()
                self.scheduleRtoLTab.update_schedule_view()


if __name__ == "__main__":
    app = AeroPlanLight()
    app.mainloop()
