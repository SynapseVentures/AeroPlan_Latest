import customtkinter as ctk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import os
from datetime import datetime
import glob


class PartListTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.setup_ui()
        self.part_list = None
        self.load_latest_partlist()  # Load latest part list upon initialization

    def setup_ui(self):
        top_frame = ctk.CTkFrame(self)
        top_frame.pack(padx=5, pady=5, fill="x")
        import_btn = ctk.CTkButton(
            top_frame, text="Import CSV", command=self.import_file
        )
        import_btn.pack(side="left", padx=5, pady=5)
        export_btn = ctk.CTkButton(
            top_frame, text="Export CSV", command=self.export_file
        )
        export_btn.pack(side="left", padx=5, pady=5)
        cascade_btn = ctk.CTkButton(
            top_frame, text="Build Product Structure", command=self.generate_cascade
        )
        cascade_btn.pack(side="left", padx=5, pady=5)
        tree_frame = ctk.CTkFrame(self)
        tree_frame.pack(padx=5, pady=5, fill="both", expand=True)
        self.tree = ttk.Treeview(tree_frame, show="headings")
        scrollbar = ttk.Scrollbar(
            tree_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        # Set default columns; we assume the CSV has these columns
        self.tree["columns"] = (
            "POST HTZ",
            "Next Assy",
            "Component Type",
            "Cascade Level",
        )
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col, anchor="center")
            self.tree.column(col, width=120, anchor="center")

    def import_file(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not file_path:
            return
        try:
            df = pd.read_csv(file_path)
            df = df.fillna("")
            for item in self.tree.get_children():
                self.tree.delete(item)
            # For our cascade, we expect at least "POST HTZ" and "POST Next Assy New"
            self.tree["columns"] = (
                tuple(df.columns)
                if "POST HTZ" in df.columns and "Next Assy" in df.columns
                else ("POST HTZ", "Next Assy", "Component Type")
            )
            for col in self.tree["columns"]:
                self.tree.heading(col, text=col, anchor="center")
                self.tree.column(col, width=120, anchor="center")
            for _, row in df.iterrows():
                values = [str(val) if pd.notna(val) else "" for val in row]
                self.tree.insert("", "end", values=values)
            self.part_list = df.copy()
            messagebox.showinfo("Success", "Data imported successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Error importing file: {str(e)}")

    def export_file(self):
        if not self.tree.get_children():
            messagebox.showwarning("Warning", "No data to export!")
            return
        current_time = datetime.now().strftime("%d%m%y%H%M")
        default_filename = f"partlist_{current_time}.csv"
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile=default_filename,
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not file_path:
            return
        try:
            columns = self.tree["columns"]
            data = []
            for item in self.tree.get_children():
                data.append(self.tree.item(item)["values"])
            df = pd.DataFrame(data, columns=columns)
            df.to_csv(file_path, index=False)
            messagebox.showinfo("Success", "Data exported successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Error exporting file: {str(e)}")

    def generate_cascade(self):
        if self.part_list is None:
            messagebox.showwarning("Warning", "No part list loaded!")
            return

        # Build cascade based on HTZ / Next Assy relationship.
        # If a part's "POST Next Assy New" equals another part's "POST HTZ", then it is a child.
        df = self.part_list.copy()
        df["Cascade Level"] = ""

        # Create a mapping from HTZ to the row index.
        parent_mapping = {}
        for idx, row in df.iterrows():
            htz = str(row.get("POST HTZ", "")).strip()
            if htz:
                parent_mapping[htz] = idx

        # First, assign levels for root parts (those that don't have a matching parent).
        root_counter = 1
        for idx, row in df.iterrows():
            next_assy = str(row.get("Next Assy", "")).strip()
            if next_assy not in parent_mapping:
                df.at[idx, "Cascade Level"] = str(root_counter)
                root_counter += 1

        # Iteratively assign cascade levels for parts that are children.
        changed = True
        while changed:
            changed = False
            for idx, row in df.iterrows():
                if df.at[idx, "Cascade Level"] == "":
                    next_assy = str(row.get("Next Assy", "")).strip()
                    if next_assy in parent_mapping:
                        parent_idx = parent_mapping[next_assy]
                        parent_level = df.at[parent_idx, "Cascade Level"]
                        if parent_level:
                            siblings = df[
                                (df["Next Assy"].str.strip() == next_assy)
                                & (df["Cascade Level"] != "")
                            ]
                            child_num = len(siblings) + 1
                            df.at[idx, "Cascade Level"] = (
                                parent_level + "." + str(child_num)
                            )
                            changed = True

        # Update the treeview with the new cascade levels.
        for item in self.tree.get_children():
            self.tree.delete(item)
        new_columns = list(df.columns)
        if "Cascade Level" not in new_columns:
            new_columns.append("Cascade Level")
        self.tree["columns"] = tuple(new_columns)
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col, anchor="center")
            self.tree.column(col, width=120, anchor="center")
        for _, row in df.iterrows():
            values = [str(val) for val in row]
            self.tree.insert("", "end", values=values)

        self.part_list = df.copy()
        messagebox.showinfo("Success", "Cascade built successfully!")

        # Save the updated part list as JSON in the data folder.
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        timestamp = datetime.now().strftime("%d%m%Y%H%M")
        filename = f"l3_{timestamp}.json"
        filepath = os.path.join(data_folder, filename)
        try:
            df.to_json(filepath, orient="records", date_format="iso")
            messagebox.showinfo("Success", f"Part list saved as JSON: {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving JSON: {str(e)}")

    def load_latest_partlist(self):
        # Load the latest part list from JSON files in the data folder.
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            return  # No data folder exists.
        json_files = glob.glob(os.path.join(data_folder, "l3_*.json"))
        if not json_files:
            return  # No JSON files found.
        latest_file = max(json_files, key=os.path.getmtime)
        try:
            df = pd.read_json(latest_file, orient="records")
            self.part_list = df.copy()
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.tree["columns"] = tuple(df.columns)
            for col in self.tree["columns"]:
                self.tree.heading(col, text=col, anchor="center")
                self.tree.column(col, width=120, anchor="center")
            for _, row in df.iterrows():
                values = [str(val) for val in row]
                self.tree.insert("", "end", values=values)
        except Exception as e:
            messagebox.showerror("Error", f"Error loading latest part list: {str(e)}")
