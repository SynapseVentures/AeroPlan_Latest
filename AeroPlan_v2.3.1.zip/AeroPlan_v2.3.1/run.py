import os
import subprocess
import sys

# Ensure the working directory is the script's directory
os.chdir(os.path.dirname(os.path.abspath(__file__)))


def main():
    """Launch AeroPlan Light using the current Python environment"""
    # Removed venv check and re-launch logic.
    # The script now assumes dependencies are installed in the current environment.

    # Launch the application
    try:
        # Use sys.executable here since it should match the venv's python at this point
        # Use sys.executable to ensure the script uses the same Python that launched run.py
        print(f"Launching main.py using: {sys.executable}")  # Optional: confirm which python is used
        subprocess.run([sys.executable, "main.py"])
    except Exception as e:
        print(f"ERROR: Failed to launch application: {e}")
        print("\nPlease ensure required packages are installed by running 'install.py'.")
        input("\nPress Enter to exit...")


if __name__ == "__main__":
    main()
