import customtkinter as ctk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import os
from datetime import datetime
import glob
import tkinter.font as tkfont # Import needed for text measurement
import tkinter as tk

# Helper function to generate the full column list
def get_template_columns():
    return [
        "Cascade Level", # Moved to first position
        "Drawing Set (HTZ)", # Source 1 for POST HTZ
        "Customer Issue-Index",
        "Title German",
        "Customer Design State",
        "Customer Release Date",
        "MOD",
        "MP",
        "Factory Code (ext.)",
        "Design Office Code",
        "Vendor Code",
        "Title English",
        "Part / Variant Nr.", # Source 2 for POST HTZ
        "Component Type",
        "CA ", # Note the trailing space, keeping as provided
        "Initial MSN",
        "Squad",
        "Structural Context",
        "Commodity",
        "Company",
        "Designer (PLM)",
        "Reason",
        "Material",
        "Priority",
        "Qualification necessary",
        "QualificationType",
        "QualificationComment",
        "DRP Tracking Comments",
        "Checklist Type",
        "3D Check Required",
        "3D Preview planned",
        "3D Preview re-planned",
        "QC0 3D planned",
        "QC0 3D re-planned",
        "3D Published planned",
        "3D Published re-planned",
        "MOD Closure Stage 0 planned",
        "MOD Closure Stage 0 re- planned", # Note the space, keeping as provided
        "MOD Closure Stage 0 achieved",
        "MOD Closure Stage 3 planned",
        "MOD Closure Stage 3 re-planned",
        "MOD Closure Stage 3 achieved",
        "ME need Date", # Source for ME Need
        "other need date",
        "PDR planned",
        "PDR re-planned",
        "PDR achieved",
        "SR Need Date",
        "CDR planned",
        "CDR re-planned",
        "CDR achieved",
        "2D Held planned",
        "2D Held re-planned",
        "2D Held QC0 planned",
        "2D Held QC0 re-planned",
        "2D Released planned",
        "2D Released re-planned",
        "Checkin comment",
        "Export Control Technical",
        "Export control DE",
        "Export Control US-EX",
        "Assessment Rationale",
        "Program",
        "Airbus classification",
        "External Classification",
        "Security Caveat",
        "Privacy Classification",
        "National Security",
        # --- Append internal columns at the end ---
        "Next Assy",
        "Responsible Plant",
        "POST HTZ" # Moved internal HTZ column to the very end
    ]

class PartListTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.setup_ui()
        self.part_list = None # The main DataFrame holding part list data
        self.loaded_partlist_file = None # Track the path of the loaded/saved JSON
        self.load_latest_partlist()  # Load latest part list upon initialization

    def setup_ui(self):
        top_frame = ctk.CTkFrame(self)
        top_frame.pack(padx=5, pady=5, fill="x")
        import_btn = ctk.CTkButton(
            top_frame, text="Import CSV", command=self.import_file
        )
        import_btn.pack(side="left", padx=5, pady=5)
        export_btn = ctk.CTkButton(
            top_frame, text="Export CSV", command=self.export_file
        )
        export_btn.pack(side="left", padx=5, pady=5)
        cascade_btn = ctk.CTkButton(
            top_frame, text="Build Product Structure", command=self.generate_cascade
        )
        cascade_btn.pack(side="left", padx=5, pady=5)
        template_btn = ctk.CTkButton(
            top_frame, text="Download Template", command=self.download_template
        )
        template_btn.pack(side="left", padx=5, pady=5)

        save_btn = ctk.CTkButton(
            top_frame, text="Save Changes", command=self.save_part_list_changes
        )
        save_btn.pack(side="left", padx=5, pady=5)

        tree_frame = ctk.CTkFrame(self)
        tree_frame.pack(padx=5, pady=5, fill="both", expand=True)
        self.tree = ttk.Treeview(tree_frame, show="headings")
        scrollbar = ttk.Scrollbar(
            tree_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)

        # --- Add Horizontal Scrollbar --- 
        scrollbar_x = ttk.Scrollbar(
            tree_frame, orient="horizontal", command=self.tree.xview
        )
        self.tree.configure(xscrollcommand=scrollbar_x.set)

        # Bind double-click event for editing
        self.tree.bind("<Double-1>", self.on_tree_cell_double_click)

        # Pack scrollbars FIRST
        scrollbar_x.pack(side="bottom", fill="x") # Pack below the tree
        scrollbar.pack(side="right", fill="y")
        # Pack tree LAST to fill remaining space
        self.tree.pack(side="top", fill="both", expand=True)

        # Set default columns to the template columns on startup
        self.tree["columns"] = get_template_columns()
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col, anchor="center")
            # Width will be set later by _adjust_column_widths
            self.tree.column(col, anchor="w")

    def import_file(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not file_path:
            return
        try:
            df = pd.read_csv(file_path)
            for item in self.tree.get_children():
                self.tree.delete(item)

            # --- Data Processing and Mapping --- 
            df = df.fillna("") # Fill missing values

            # 1. Check for essential source columns
            required_source_cols = ["Drawing Set (HTZ)", "Part / Variant Nr.", "Component Type", "ME need Date", "Next Assy", "Responsible Plant"]
            missing_cols = [col for col in required_source_cols if col not in df.columns]
            if missing_cols:
                messagebox.showerror("Error", f"Import failed. Missing required columns in CSV: {', '.join(missing_cols)}")
                return

            # 2. Add the 'Cascade Level' column (will be populated later)
            df['Cascade Level'] = "" 

            # 3. Create internal 'POST HTZ' column 
            def create_post_htz(row):
                drawing_set = str(row["Drawing Set (HTZ)"]).replace("-", "").replace(" ", "")
                part_variant = str(row["Part / Variant Nr."]).replace("-", "").replace(" ", "")
                combined = drawing_set + part_variant
                return combined[:12] # Take first 12 characters

            df['POST HTZ'] = df.apply(create_post_htz, axis=1)

            # 4. Create internal 'ME Need' column (maps from 'ME need Date')
            df['ME Need'] = df['ME need Date']

            # 5. Ensure all expected columns exist and are in the right order (as per get_template_columns)
            all_expected_columns = get_template_columns()
            for col in all_expected_columns:
                if col not in df.columns:
                    df[col] = "" # Add any potentially missing non-essential columns
            df = df[all_expected_columns] # Reorder columns

            # --- Update Treeview --- 
            self.part_list = df.copy() # Store processed part list first
            self._populate_treeview_with_merged_data() # Call helper to load schedule and fill tree
            messagebox.showinfo("Success", "Data imported successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Error importing file: {str(e)}")

    def export_file(self):
        if not self.tree.get_children():
            messagebox.showwarning("Warning", "No data to export!")
            return
        current_time = datetime.now().strftime("%d%m%y%H%M")
        default_filename = f"partlist_{current_time}.csv"
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile=default_filename,
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not file_path:
            return
        try:
            columns = self.tree["columns"]
            data = []
            for item in self.tree.get_children():
                data.append(self.tree.item(item)["values"])
            df = pd.DataFrame(data, columns=columns)
            df.to_csv(file_path, index=False)
            messagebox.showinfo("Success", "Data exported successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Error exporting file: {str(e)}")

    def generate_cascade(self):
        # --- Debug Step 1: Check if POST HTZ exists at the start --- 
        if self.part_list is None:
            messagebox.showwarning("Warning", "No part list loaded!")
            return
        if 'POST HTZ' not in self.part_list.columns:
            messagebox.showerror("Error", "Internal data error: 'POST HTZ' column not found in loaded part list before generating cascade. Please re-import.")
            return
        # --- End Debug Step 1 ---

        # Build cascade based on HTZ / Next Assy relationship.
        # If a part's "POST Next Assy New" equals another part's "POST HTZ", then it is a child.
        df = self.part_list.copy()
        df["Cascade Level"] = ""

        # Create a mapping from HTZ to the row index.
        parent_mapping = {}
        for idx, row in df.iterrows():
            htz = str(row.get("POST HTZ", "")).strip()
            if htz:
                parent_mapping[htz] = idx

        # First, assign levels for root parts (those that don't have a matching parent).
        root_counter = 1
        for idx, row in df.iterrows():
            next_assy = str(row.get("Next Assy", "")).strip()
            if next_assy not in parent_mapping:
                df.at[idx, "Cascade Level"] = str(root_counter)
                root_counter += 1

        # Iteratively assign cascade levels for parts that are children.
        changed = True
        while changed:
            changed = False
            for idx, row in df.iterrows():
                if df.at[idx, "Cascade Level"] == "":
                    next_assy = str(row.get("Next Assy", "")).strip()
                    if next_assy in parent_mapping:
                        parent_idx = parent_mapping[next_assy]
                        parent_level = df.at[parent_idx, "Cascade Level"]
                        if parent_level:
                            siblings = df[
                                (df["Next Assy"].str.strip() == next_assy)
                                & (df["Cascade Level"] != "")
                            ]
                            child_num = len(siblings) + 1
                            df.at[idx, "Cascade Level"] = (
                                parent_level + "." + str(child_num)
                            )
                            changed = True

        self.part_list = df.copy()
        self._populate_treeview_with_merged_data() # Refresh tree with merged data

        messagebox.showinfo("Success", "Cascade built successfully!")

        # Save the updated part list as JSON in the data folder.
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        timestamp = datetime.now().strftime("%d%m%Y%H%M")
        filename = f"l3_{timestamp}.json"
        filepath = os.path.join(data_folder, filename)
        try:
            # --- Debug Step 2: Check columns right before saving --- 
            df_to_save = self.part_list.copy() # Use the updated self.part_list
            print("\n--- Debug: Columns in DataFrame being saved to JSON ---")
            print(list(df_to_save.columns))
            print("------------------------------------------------------\n")
            # --- End Debug Step 2 ---

            # Explicitly check if POST HTZ is in the df before saving
            if 'POST HTZ' not in df_to_save.columns:
                messagebox.showerror("Internal Error", "POST HTZ column missing before saving JSON!")
                return

            df_to_save.to_json(filepath, orient="records", date_format="iso")
            self.loaded_partlist_file = filepath # Store the path of the newly saved file
            messagebox.showinfo("Success", f"Part list saved as JSON: {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving JSON: {str(e)}")

    def load_latest_partlist(self):
        # Load the latest part list from JSON files in the data folder.
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            return  # No data folder exists.
        json_files = glob.glob(os.path.join(data_folder, "l3_*.json"))
        if not json_files:
            return  # No JSON files found.
        latest_file = max(json_files, key=os.path.getmtime)
        try:
            df = pd.read_json(latest_file, orient="records")
            self.part_list = df.copy()
            self.loaded_partlist_file = latest_file # Store the path
            self._populate_treeview_with_merged_data() # Refresh tree with merged data
        except Exception as e:
            messagebox.showerror("Error", f"Error loading latest part list: {str(e)}")

    def download_template(self):
        """Generates a template CSV file with all required external columns."""
        all_columns = get_template_columns()
        # Exclude 'Cascade Level' from the file template
        template_columns_for_file = [col for col in all_columns if col != "Cascade Level"]

        template_data = {}

        # Create one row of example data / placeholders
        example_row = []
        for col in template_columns_for_file: # Use the filtered list here
            if col == "Drawing Set (HTZ)":
                example_row.append("DRAWINGSET123")
            elif col == "Part / Variant Nr.":
                example_row.append("VAR-01")
            elif col == "Next Assy":
                example_row.append("PARENT-HTZ-COMBINED") # Example shows where parent POST HTZ would go
            elif col == "Component Type":
                example_row.append("Single Part")
            elif col == "ME need Date":
                example_row.append("25.12.24")
            elif col == "Responsible Plant":
                example_row.append("PlantX")
            else:
                example_row.append("") # Empty placeholder for other columns

        # Assign the example row to the dictionary
        for i, col_name in enumerate(template_columns_for_file): # Use the filtered list here
            template_data[col_name] = [example_row[i]] # List with one element

        template_df = pd.DataFrame(template_data)

        # Prompt user for save location
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile="partlist_template.csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="Save Part List Template"
        )

        if not file_path:
            return # User cancelled

        try:
            template_df.to_csv(file_path, index=False, encoding='utf-8-sig') # Use utf-8-sig for better Excel compatibility
            messagebox.showinfo("Success", f"Template saved successfully to:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving template file: {str(e)}")

    def save_part_list_changes(self):
        """Saves the current in-memory part list back to the last loaded/saved JSON file."""
        if self.part_list is None:
            messagebox.showwarning("Warning", "No part list data to save.")
            return

        if self.loaded_partlist_file is None:
            messagebox.showwarning("Warning", "No file has been loaded or saved yet in this session. Use 'Export CSV' or 'Build Product Structure' first.")
            return

        if not os.path.exists(os.path.dirname(self.loaded_partlist_file)):
            messagebox.showerror("Error", f"The target directory for saving does not exist anymore: {os.path.dirname(self.loaded_partlist_file)}")
            return

        try:
            # Prepare DataFrame for saving (ensure correct columns if needed, though self.part_list should be correct)
            df_to_save = self.part_list.copy()
            
            # Optionally drop columns not intended for JSON, though currently all should be saved
            # df_to_save = df_to_save[columns_to_keep_in_json]

            df_to_save.to_json(self.loaded_partlist_file, orient="records", date_format="iso")
            messagebox.showinfo("Success", f"Changes saved successfully to:\n{self.loaded_partlist_file}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving changes to {os.path.basename(self.loaded_partlist_file)}: {str(e)}")

    def _load_latest_rtol_schedule(self):
        """Loads the latest RtoL schedule JSON file from the data folder."""
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        pattern = os.path.join(data_folder, "RtoL_*.json")
        files = glob.glob(pattern)
        if not files:
            # No schedule found, return an empty DataFrame with expected columns
            return pd.DataFrame(columns=["Part Number", "Check End", "Release End"])
        latest_file = max(files, key=os.path.getmtime)
        try:
            df = pd.read_json(latest_file, orient="records")
            # Select only the necessary columns for merging
            if all(col in df.columns for col in ["Part Number", "Check End", "Release End"]):
                return df[["Part Number", "Check End", "Release End"]]
            else:
                print("Warning: Latest RtoL schedule JSON is missing required columns (Part Number, Check End, Release End).")
                return pd.DataFrame(columns=["Part Number", "Check End", "Release End"])
        except Exception as e:
            messagebox.showerror("Error", f"Error loading latest RtoL schedule ({os.path.basename(latest_file)}): {str(e)}")
            return pd.DataFrame(columns=["Part Number", "Check End", "Release End"])

    def _adjust_column_widths(self):
        """Adjust the width of columns based on header and content length."""
        # Use a default font for measurement; Treeview font is complex to get reliably
        font = tkfont.Font()

        col_widths = {}
        columns = self.tree["columns"]

        for col in columns:
            # Measure header width
            header_text = self.tree.heading(col, "text")
            header_width = font.measure(header_text)
            col_widths[col] = header_width + 10 # Initial width + padding

        # Measure content width for each row
        for item in self.tree.get_children():
            values = self.tree.item(item)['values']
            for i, val in enumerate(values):
                if i < len(columns):
                    col = columns[i]
                    content_width = font.measure(str(val))
                    col_widths[col] = max(col_widths[col], content_width + 10) # Use max width + padding

        # Apply the calculated widths
        for col in columns:
            # Optionally add min/max width constraints
            final_width = max(50, min(col_widths[col], 600)) # e.g., min 50, max 600
            self.tree.column(col, width=final_width, anchor="w")

    def on_tree_cell_double_click(self, event):
        """Handle double-click event on the treeview cell for editing."""
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell":
            return # Click was not on a cell

        column_id = self.tree.identify_column(event.x)
        row_id = self.tree.identify_row(event.y)
        if not row_id:
            return # Click was not on a valid row

        try:
            # Get column index and name
            column_index = int(column_id.replace("#", "")) - 1
            column_name = self.tree["columns"][column_index]

            # Prevent editing generated columns
            if column_name in ["Cascade Level", "POST HTZ"]:
                 messagebox.showinfo("Info", f"Column '{column_name}' is generated automatically and cannot be edited directly.")
                 return

        except (ValueError, IndexError):
            return # Could not determine valid column

        # Get cell bounding box
        x, y, width, height = self.tree.bbox(row_id, column_id)

        # Get current value
        current_value = self.tree.set(row_id, column_id)

        # Create Entry widget
        entry = tk.Entry(self.tree, borderwidth=0)
        entry.place(x=x, y=y, width=width, height=height)
        entry.insert(0, current_value)
        entry.focus_force() # Give focus to the entry
        entry.select_range(0, tk.END) # Select all text

        # --- Nested function to save the edit --- 
        def save_edit(save_event=None):
            new_value = entry.get()
            
            # 1. Update Treeview
            self.tree.set(row_id, column_id, new_value)

            # 2. Update underlying DataFrame (self.part_list)
            try:
                row_index = self.tree.index(row_id) # Get the numerical index
                if self.part_list is not None and row_index < len(self.part_list):
                    # Use .at for fast label-based access (assuming index matches Treeview order)
                    self.part_list.at[row_index, column_name] = new_value

                    # Special handling if source columns for POST HTZ or ME Need are changed
                    if column_name in ["Drawing Set (HTZ)", "Part / Variant Nr."]:
                        drawing_set = str(self.part_list.at[row_index, "Drawing Set (HTZ)"]).replace("-", "").replace(" ", "")
                        part_variant = str(self.part_list.at[row_index, "Part / Variant Nr."]).replace("-", "").replace(" ", "")
                        combined = drawing_set + part_variant
                        new_post_htz = combined[:12]
                        self.part_list.at[row_index, 'POST HTZ'] = new_post_htz
                        # Update the Treeview for POST HTZ as well
                        self.tree.set(row_id, "POST HTZ", new_post_htz)

                    if column_name == "ME need Date":
                        self.part_list.at[row_index, 'ME Need'] = new_value

                else:
                    print(f"Warning: Could not find row index {row_index} in self.part_list during edit.")
            except Exception as e:
                print(f"Error updating DataFrame during edit: {e}")
                messagebox.showerror("Error", f"Failed to update internal data: {e}")

            # Destroy the entry widget
            entry.destroy()

        # --- Bind events for the Entry widget --- 
        entry.bind("<Return>", save_edit) # Save on Enter
        entry.bind("<FocusOut>", lambda e: entry.destroy()) # Destroy on losing focus (cancel edit)
        entry.bind("<Escape>", lambda e: entry.destroy()) # Destroy on Escape (cancel edit)

    def _populate_treeview_with_merged_data(self):
        """Loads RtoL schedule, merges with part list, and populates the Treeview."""
        if self.part_list is None:
            print("Warning: Part list not loaded, cannot populate treeview.")
            return

        # Load the latest RtoL schedule
        rtol_schedule_df = self._load_latest_rtol_schedule()

        # Merge RtoL schedule with the current part list
        # Use left merge to keep all parts from part_list
        merged_df = pd.merge(
            self.part_list,
            rtol_schedule_df,
            left_on="POST HTZ",
            right_on="Part Number",
            how="left",
            suffixes=("", "_rtol") # Add suffix to avoid potential column name clashes if needed
        )

        # Clear existing tree items
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Define the columns for the Treeview (should match get_template_columns)
        tree_columns = get_template_columns()
        self.tree["columns"] = tree_columns
        for col in tree_columns:
            self.tree.heading(col, text=col, anchor="center")
            # Width will be set later
            self.tree.column(col, anchor="w")

        # Populate the treeview
        for _, row in merged_df.iterrows():
            values = []
            for col_name in tree_columns:
                if col_name == "2D Held QC0 planned":
                    # Use 'Check End' from merged RtoL data, default to empty if missing
                    values.append(row.get("Check End", ""))
                elif col_name == "2D Released planned":
                    # Use 'Release End' from merged RtoL data, default to empty if missing
                    values.append(row.get("Release End", ""))
                else:
                    # Use the value from the main part list DataFrame
                    values.append(str(row.get(col_name, "")))
            self.tree.insert("", "end", values=values)

        # Adjust column widths based on the new content
        self._adjust_column_widths()
