import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime
import pandas as pd
import glob
import os
import json
from gantt_chart import generate_gantt_chart
from fte_curve import generate_fte_curve
import math

# Helper Functions for Date/Week Conversion
def week_str_to_dt(week_str):
    """Convert 'YYYY-WW' string to datetime (start of week Monday)."""
    if not isinstance(week_str, str) or '-' not in week_str:
        return pd.NaT
    try:
        year, week = map(int, week_str.split('-'))
        # Handle potential week 0 or > 53 if needed, though isocalendar usually handles this
        return datetime.fromisocalendar(year, week, 1) # Monday is day 1
    except ValueError:
        return pd.NaT

def dt_to_week_str(dt):
    """Convert datetime object to 'YYYY-WW' string."""
    if pd.isna(dt):
        return None # Or return empty string ""
    try:
        iso_year, iso_week, _ = dt.isocalendar()
        return f"{iso_year}-{iso_week:02d}"
    except AttributeError:
        return None

class ScheduleRtoLTab(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.parts_df = None  # Loaded part list DataFrame
        self.schedule_data = None  # Resulting schedule DataFrame
        self.default_efforts = {
            "Single Part": {"Check": 5, "Release": 3},
            "Sub-Assembly": {"Check": 6, "Release": 4},
            "Assembly": {"Check": 11, "Release": 5},
            "Design Solution": {"Check": 11, "Release": 5},
        }
        self.current_efforts = self.default_efforts.copy()
        self.parent_schedule_map = {}  # Mapping from cascade string to scheduled entry
        self.setup_ui()  # Create UI widgets first
        # Attempt to load the latest saved RtoL schedule
        loaded = self.load_latest_schedule("RtoL_")
        if loaded is not None:
            self.schedule_data = loaded.copy()
            self.update_schedule_view()

    def load_latest_schedule(self, prefix):
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        pattern = os.path.join(data_folder, f"{prefix}*.json")
        files = glob.glob(pattern)
        if not files:
            # Optionally inform the user
            # messagebox.showinfo("Info", f"No schedule files found with prefix {prefix}")
            return None
        latest_file = max(files, key=os.path.getmtime)
        try:
            df = pd.read_json(latest_file, orient="records")
            return df
        except Exception as e:
            messagebox.showerror("Error", f"Error loading schedule: {e}")
            return None

    def update_schedule_view(self):
        # Clear the existing table entries
        for item in self.schedule_tree.get_children():
            self.schedule_tree.delete(item)
        if self.schedule_data is not None and not self.schedule_data.empty:
            cols = list(self.schedule_data.columns)
            self.schedule_tree["columns"] = cols
            for col in cols:
                self.schedule_tree.heading(col, text=col, anchor="center")
                self.schedule_tree.column(col, width=120, anchor="center")
            for _, row in self.schedule_data.iterrows():
                self.schedule_tree.insert("", "end", values=[row[col] for col in cols])

    def setup_ui(self):
        # Settings Row: Efforts, FTE, Start Date, Plant Dates
        settings_frame = ctk.CTkFrame(self)
        settings_frame.pack(padx=10, pady=5, fill="x")

        # --- Efforts Section ---
        efforts_frame = ctk.CTkFrame(settings_frame, width=300, height=220)
        efforts_frame.pack(side="left", padx=10, pady=5)
        efforts_frame.pack_propagate(False)
        ctk.CTkLabel(
            efforts_frame, text="RtoL Effort (hrs)", font=("Arial", 12, "bold")
        ).pack(padx=10, pady=10)
        self.rtol_effort_inputs = {}
        for comp_type, efforts in self.default_efforts.items():
            frame = ctk.CTkFrame(efforts_frame)
            frame.pack(padx=5, pady=5, fill="x")
            ctk.CTkLabel(frame, text=comp_type, width=100).pack(side="left")
            check_var = tk.StringVar(value=str(efforts["Check"]))
            check_entry = ctk.CTkEntry(frame, textvariable=check_var, width=60)
            check_entry.pack(side="left", padx=5)
            release_var = tk.StringVar(value=str(efforts["Release"]))
            release_entry = ctk.CTkEntry(frame, textvariable=release_var, width=60)
            release_entry.pack(side="left", padx=5)
            self.rtol_effort_inputs[comp_type] = {
                "Check": check_var,
                "Release": release_var,
            }

        # --- FTE Section ---
        fte_frame = ctk.CTkFrame(settings_frame, width=300, height=220)
        fte_frame.pack(side="left", padx=10, pady=5)
        fte_frame.pack_propagate(False)
        ctk.CTkLabel(
            fte_frame, text="RtoL FTE (35hrs/week)", font=("Arial", 12, "bold")
        ).pack(padx=10, pady=10)
        fte_input_frame = ctk.CTkFrame(fte_frame)
        fte_input_frame.pack(padx=10, pady=5, fill="x")
        check_fte_frame = ctk.CTkFrame(fte_input_frame)
        check_fte_frame.pack(side="left", padx=5, pady=5)
        ctk.CTkLabel(check_fte_frame, text="Check FTE").pack(side="top")
        self.rtol_check_fte = ctk.CTkEntry(check_fte_frame, width=100) # Store reference
        self.rtol_check_fte.pack(side="top", padx=5, pady=5)
        self.rtol_check_fte.insert(0, "1") # Default value
        release_fte_frame = ctk.CTkFrame(fte_input_frame)
        release_fte_frame.pack(side="left", padx=5, pady=5)
        ctk.CTkLabel(release_fte_frame, text="Release FTE").pack(side="top")
        self.rtol_release_fte = ctk.CTkEntry(release_fte_frame, width=100) # Store reference
        self.rtol_release_fte.pack(side="top", padx=5, pady=5)
        self.rtol_release_fte.insert(0, "1") # Default value

        # ===== Buttons Section =====
        buttons_frame = ctk.CTkFrame(self)
        buttons_frame.pack(padx=10, pady=5, fill="x")
        ctk.CTkButton(
            buttons_frame, text="Generate RtoL Schedule", command=self.generate_schedule
        ).pack(side="left", padx=10, pady=5)
        ctk.CTkButton(
            buttons_frame, text="View RtoL Gantt Chart", command=self.view_gantt_chart
        ).pack(side="left", padx=10, pady=5)
        ctk.CTkButton(
            buttons_frame, text="View RtoL FTE Curve", command=self.view_fte_curve
        ).pack(side="left", padx=10, pady=5)
        ctk.CTkButton(
            buttons_frame, text="Clear/New Schedule", command=self.clear_schedule
        ).pack(side="left", padx=10, pady=5)

        # ===== Schedule Table Section =====
        table_frame = ctk.CTkFrame(self)
        table_frame.pack(padx=10, pady=10, fill="both", expand=True)
        self.schedule_tree = ttk.Treeview(table_frame, show="headings")
        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.schedule_tree.yview
        )
        self.schedule_tree.configure(yscrollcommand=scrollbar.set)
        self.schedule_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.schedule_tree["columns"] = (
            "Part Number",
            "Cascade Level",
            "Component Type",
            "Schedule Info",
        )
        for col in self.schedule_tree["columns"]:
            self.schedule_tree.heading(col, text=col, anchor="center")
            self.schedule_tree.column(col, width=150, anchor="center")
        # Add double-click event binding for the schedule tree
        self.schedule_tree.bind("<Double-1>", self.on_schedule_double_click)

    def load_parts(self):
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        json_files = glob.glob(os.path.join(data_folder, "l3_*.json"))
        if not json_files:
            return None
        latest_file = max(json_files, key=os.path.getmtime)
        try:
            parts_df = pd.read_json(latest_file, orient="records")
            return parts_df
        except Exception as e:
            messagebox.showerror("Error", f"Error loading part list: {str(e)}")
            return None

    def generate_schedule(self):
        parts_df_original = self.load_parts()
        if parts_df_original is None or parts_df_original.empty:
            messagebox.showwarning("Warning", "No part list available for scheduling!")
            return

        # --- Create a local copy to work with ---
        local_parts_df = parts_df_original.copy()

        if "Cascade Level" not in local_parts_df.columns:
            local_parts_df["Cascade Level"] = ""
        if "Component Type" not in local_parts_df.columns:
             print("Warning: 'Component Type' column missing. Assuming 'Single Part'.")
             local_parts_df["Component Type"] = "Single Part"
        if "POST HTZ" not in local_parts_df.columns:
             messagebox.showerror("Error", "Part list missing 'POST HTZ' (Part Number).")
             return

        # --- Get FTE and Calculate Capacity ---
        try:
            check_fte = float(self.rtol_check_fte.get())
            release_fte = float(self.rtol_release_fte.get())
            capacity_check = check_fte * 35  # Assuming 35 hours/week/FTE
            capacity_release = release_fte * 35
            if capacity_check <= 0 or capacity_release <= 0:
                raise ValueError("FTE values must be positive.")
        except ValueError as e:
            messagebox.showerror("Error", f"Invalid FTE inputs: {e}")
            return

        # --- Update current_efforts from UI ---
        try:
            for comp_type, inputs in self.rtol_effort_inputs.items():
                self.current_efforts[comp_type] = {
                    "Check": float(inputs["Check"].get()),
                    "Release": float(inputs["Release"].get()),
                }
                if self.current_efforts[comp_type]["Check"] < 0 or self.current_efforts[comp_type]["Release"] < 0:
                    raise ValueError(f"Effort for {comp_type} cannot be negative.")
        except ValueError as e:
            messagebox.showerror("Error", f"Invalid effort values: {e}")
            return

        # --- Parse Deadline from "ME NEED" Column and Calculate Depth ---
        deadline_col_name = "ME need Date" # Use the original source column name
        if deadline_col_name not in local_parts_df.columns:
            messagebox.showerror("Error", f"Part list is missing the required '{deadline_col_name}' column.")
            return

        def parse_me_need_date(date_str):
            if pd.isna(date_str) or not isinstance(date_str, str) or date_str.strip() == "":
                return pd.NaT
            cleaned_date_str = date_str.strip()
            try:
                # Expect dd.mm.yyyy format
                return datetime.strptime(cleaned_date_str, "%d.%m.%Y")
            except ValueError:
                # If format fails, log and return NaT
                print(f"Warning: Could not parse date '{cleaned_date_str}' with expected format (dd.mm.yyyy).")
                return pd.NaT

        local_parts_df["Deadline Date"] = local_parts_df[deadline_col_name].apply(parse_me_need_date)

        # --- Debugging: Log parts with invalid/missing deadlines BEFORE dropping ---
        invalid_deadline_parts = local_parts_df[local_parts_df["Deadline Date"].isna()]
        if not invalid_deadline_parts.empty:
            print(f"\n--- Debug: Parts with Missing/Invalid '{deadline_col_name}' Dates ---")
            for index, row in invalid_deadline_parts.iterrows():
                part_num = row.get("POST HTZ", "N/A")
                me_need_val = row.get(deadline_col_name, "[Not Found]")
                print(f"  Part Number: {part_num}, '{deadline_col_name}' Value: '{me_need_val}'")
            print("--------------------------------------------------------\n")
        # --- End Debugging ---

        # Drop parts with no deadline as they cannot be scheduled RtoL
        original_count = len(local_parts_df)
        local_parts_df.dropna(subset=["Deadline Date"], inplace=True)
        if len(local_parts_df) < original_count:
            messagebox.showwarning("Warning", f"{original_count - len(local_parts_df)} parts removed due to missing or invalid '{deadline_col_name}' dates.")
        if local_parts_df.empty:
            messagebox.showerror("Error", f"No parts with valid '{deadline_col_name}' dates found.")
            return

        local_parts_df["Depth"] = local_parts_df["Cascade Level"].apply(
            lambda x: len(str(x).split('.')) if pd.notna(x) and str(x).strip() else 0
        )

        # --- RtoL Scheduling with Resource Constraints ---
        schedule = {} # Stores {part_num: {check_start_dt: ..., release_start_dt: ...}}
        weekly_check_usage = {} # Stores {'YYYY-WW': usage}
        weekly_release_usage = {} # Stores {'YYYY-WW': usage}

        # Sort: Top-level first (low depth), then latest deadline first
        parts_sorted_df = local_parts_df.sort_values(by=["Depth", "Deadline Date"], ascending=[True, False])

        # --- Helper to find parent ---
        def get_parent_cascade(cascade_str):
            if not cascade_str or '.' not in cascade_str:
                return None
            return '.'.join(cascade_str.split('.')[:-1])

        # --- Map Part Number to Cascade for easier lookup ---
        part_num_to_cascade = pd.Series(parts_sorted_df['Cascade Level'].values, index=parts_sorted_df['POST HTZ']).to_dict()
        cascade_to_part_num = {v: k for k, v in part_num_to_cascade.items() if v} # Inverse map, ignore empty cascades

        # --- Iterate through sorted parts ---
        for _, part in parts_sorted_df.iterrows():
            part_num = part["POST HTZ"]
            cascade = str(part["Cascade Level"]) if pd.notna(part["Cascade Level"]) else ""
            comp_type = part["Component Type"]
            deadline_dt = part["Deadline Date"] # Already a datetime object

            # Get required efforts
            req_check = self.current_efforts.get(comp_type, {"Check": 0})["Check"]
            req_release = self.current_efforts.get(comp_type, {"Release": 0})["Release"]

            # 1. Deadline Constraint: Latest release start is deadline week
            latest_possible_release_start_dt = deadline_dt

            # 2. Parent Constraint: Release must finish before parent check starts
            parent_cascade = get_parent_cascade(cascade)
            if parent_cascade:
                parent_part_num = cascade_to_part_num.get(parent_cascade)
                if parent_part_num and parent_part_num in schedule:
                    parent_check_start_dt = schedule[parent_part_num].get("Check Start Date")
                    if not pd.isna(parent_check_start_dt):
                        # Child release must be <= parent check start - 1 week
                        parent_constraint_dt = parent_check_start_dt - pd.Timedelta(weeks=1)
                        # Take the earlier date between deadline and parent constraint
                        if pd.isna(latest_possible_release_start_dt) or parent_constraint_dt < latest_possible_release_start_dt:
                             latest_possible_release_start_dt = parent_constraint_dt
                else:
                    # This implies parent wasn't scheduled yet, which is expected with Depth ascending sort
                    pass

            # If latest_possible_release_start_dt became NaT (e.g. parent check was NaT), handle it.
            # This shouldn't happen if deadlines are mandatory and parents are processed first.
            if pd.isna(latest_possible_release_start_dt):
                 print(f"Error: Could not determine latest possible start for {part_num}. Skipping.")
                 schedule[part_num] = { # Add entry with NaT to avoid lookup errors for children
                     "Part Number": part_num, "Cascade Level": cascade, "Component Type": comp_type,
                     "Check Start Date": pd.NaT, "Release Start Date": pd.NaT, "Deadline Date": deadline_dt
                 }
                 continue


            # 3. Backtrack for Resource Capacity
            candidate_release_start_dt = latest_possible_release_start_dt
            found_slot = False
            max_iterations = 52 * 5 # Safety break: Limit search to 5 years back
            iterations = 0

            while not found_slot and iterations < max_iterations:
                iterations += 1
                candidate_check_start_dt = candidate_release_start_dt - pd.Timedelta(weeks=1)

                check_week_str = dt_to_week_str(candidate_check_start_dt)
                release_week_str = dt_to_week_str(candidate_release_start_dt)

                # Check capacity if dates are valid
                if check_week_str and release_week_str:
                    current_check_usage = weekly_check_usage.get(check_week_str, 0)
                    current_release_usage = weekly_release_usage.get(release_week_str, 0)

                    if (current_check_usage + req_check <= capacity_check and
                        current_release_usage + req_release <= capacity_release):

                        # Found a slot!
                        final_check_start_dt = candidate_check_start_dt
                        final_release_start_dt = candidate_release_start_dt

                        # Update usage
                        weekly_check_usage[check_week_str] = current_check_usage + req_check
                        weekly_release_usage[release_week_str] = current_release_usage + req_release

                        # Store result (datetime objects)
                        schedule[part_num] = {
                            "Part Number": part_num,
                            "Cascade Level": cascade,
                            "Component Type": comp_type,
                            "Check Start Date": final_check_start_dt,
                            "Release Start Date": final_release_start_dt,
                            "Deadline Date": deadline_dt
                        }
                        # Store the original ME Need string as well
                        schedule[part_num]["ME Need Original"] = part[deadline_col_name]
                        found_slot = True
                        break # Exit while loop

                # If no slot found or dates invalid, backtrack
                candidate_release_start_dt -= pd.Timedelta(weeks=1)

            if not found_slot:
                 print(f"Warning: Could not find capacity slot for {part_num} within {max_iterations} weeks of its deadline/parent constraint. Scheduling failed for this part.")
                 # Store NaT dates so children can potentially still be scheduled
                 schedule[part_num] = {
                     "Part Number": part_num, "Cascade Level": cascade, "Component Type": comp_type,
                     "Check Start Date": pd.NaT, "Release Start Date": pd.NaT, "Deadline Date": deadline_dt
                 }


        # --- Convert schedule dict to DataFrame with string dates ---
        schedule_entries = []
        for part_num, data in schedule.items():
             # Handle potential NaT dates gracefully during conversion
             check_start_str = dt_to_week_str(data.get("Check Start Date"))
             release_start_str = dt_to_week_str(data.get("Release Start Date"))
             # Use the original ME Need string instead of the calculated deadline week
             me_need_original_str = data.get("ME Need Original", "N/A" if check_start_str else "Error") # Get stored original value

             schedule_entries.append({
                  "Part Number": data["Part Number"],
                  "Cascade Level": data["Cascade Level"],
                  "Component Type": data["Component Type"],
                  "Check Start": check_start_str,
                  "Check End": check_start_str, # Assuming 1 week duration
                  "Release Start": release_start_str,
                  "Release End": release_start_str, # Assuming 1 week duration
                  "ME Need": me_need_original_str # Use the original string with the new column name
             })

        # Create the final DataFrame
        self.schedule_data = pd.DataFrame(schedule_entries)

        # Optional: Reorder columns if needed
        final_columns = [
            "Part Number", "Cascade Level", "Component Type",
            "Check Start", "Check End", "Release Start", "Release End", "ME Need"
        ]
        # Ensure all columns exist, adding missing ones as None/empty
        for col in final_columns:
             if col not in self.schedule_data.columns:
                  self.schedule_data[col] = None # Or pd.NA
        self.schedule_data = self.schedule_data[final_columns]

        # Update the treeview
        self.update_schedule_view()
        messagebox.showinfo("Success", "RtoL schedule generated respecting dependencies and capacity.")

        # --- Save the new schedule ---
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        timestamp = datetime.now().strftime("%d%m%Y%H%M")
        filename = f"RtoL_{timestamp}.json"
        filepath = os.path.join(data_folder, filename)
        try:
            # Use date_format='iso' for consistency, though week strings aren't directly affected
            self.schedule_data.to_json(filepath, orient="records", date_format="iso", default_handler=str) # Handle NaT
            messagebox.showinfo("Success", f"RtoL schedule saved as JSON: {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving schedule JSON: {e}")

    def view_gantt_chart(self):
        if self.schedule_data is None or self.schedule_data.empty:
            messagebox.showwarning("Warning", "No schedule data generated yet.")
            return
        try:
            # Pass only the schedule DataFrame to the Gantt chart function
            # Assumes generate_gantt_chart can handle the 'YYYY-WW' format directly or infer timing
            generate_gantt_chart(self.schedule_data)
        except Exception as e:
            # Check if the error is due to generate_gantt_chart missing arguments
            import inspect
            try:
                sig = inspect.signature(generate_gantt_chart)
                num_required = len([
                    p for p in sig.parameters.values()
                    if p.default == inspect.Parameter.empty and p.kind == p.POSITIONAL_OR_KEYWORD
                ])
                if num_required > 1:
                     messagebox.showerror("Error", f"Gantt chart function might need more arguments. Error: {e}")
                else:
                     messagebox.showerror("Error", f"Error displaying Gantt chart: {e}")

            except Exception: # Fallback if inspection fails
                 messagebox.showerror("Error", f"Error displaying Gantt chart: {e}")


    def view_fte_curve(self):
        if self.schedule_data is None or self.schedule_data.empty:
            messagebox.showwarning("Warning", "No schedule data generated yet.")
            return

        # Use current efforts from UI for the curve visualization
        current_efforts_for_curve = {}
        try:
             for comp_type, inputs in self.rtol_effort_inputs.items():
                  check_effort = float(inputs["Check"].get())
                  release_effort = float(inputs["Release"].get())
                  if check_effort < 0 or release_effort < 0:
                      raise ValueError(f"Effort for {comp_type} cannot be negative.")
                  current_efforts_for_curve[comp_type] = {
                       "Check": check_effort,
                       "Release": release_effort
                  }
        except ValueError as e:
             messagebox.showerror("Error", f"Invalid effort values for FTE curve: {e}. Using defaults.")
             # Fallback to defaults if UI inputs are invalid
             current_efforts_for_curve = self.default_efforts.copy()
        except Exception as e:
             messagebox.showerror("Error", f"Could not read effort values: {e}. Using defaults.")
             current_efforts_for_curve = self.default_efforts.copy()


        try:
            generate_fte_curve(self.schedule_data, current_efforts_for_curve)
        except Exception as e:
            messagebox.showerror("Error", f"Error displaying FTE curve: {e}")

    def on_schedule_double_click(self, event):
        """Handle double-click on schedule tree to enable cell editing"""
        region = self.schedule_tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        
        column = self.schedule_tree.identify_column(event.x)
        column_idx = int(column[1:]) - 1  # Convert #1, #2, etc. to 0, 1, etc.
        
        if self.schedule_tree["columns"][column_idx] not in [
            "Check Start", "Check End", "Release Start", "Release End"
        ]:
            return  # Only allow editing date fields
            
        rowid = self.schedule_tree.identify_row(event.y)
        if not rowid:
            return
            
        x, y, width, height = self.schedule_tree.bbox(rowid, column)
        current_value = self.schedule_tree.set(rowid, column)
        
        entry = tk.Entry(self.schedule_tree)
        entry.place(x=x, y=y, width=width, height=height)
        entry.insert(0, current_value)
        entry.focus_set()
        
        def save_schedule_edit(event):
            new_value = entry.get()
            if new_value.strip() != "":
                # Validate the date format (yyyy-cw)
                try:
                    if not new_value.strip().isalpha():  # Skip validation for non-date values
                        year_str, week_str = new_value.split("-")
                        year = int(year_str)
                        week = int(week_str)
                        # Check valid year and week range
                        if not (2000 <= year <= 2100 and 1 <= week <= 53):
                            raise ValueError
                except ValueError:
                    messagebox.showerror(
                        "Error", "Invalid date format. Use yyyy-ww (e.g., 2023-42)."
                    )
                    entry.destroy()
                    return
                    
            # Update the value in the treeview and the underlying DataFrame
            self.schedule_tree.set(rowid, column, new_value)
            
            # Update the DataFrame
            row_index = self.schedule_tree.index(rowid)
            col_name = self.schedule_tree["columns"][column_idx]
            if self.schedule_data is not None and not self.schedule_data.empty and row_index < len(self.schedule_data):
                self.schedule_data.at[row_index, col_name] = new_value
                
                # Save the updated schedule
                self.save_current_schedule()
                
            entry.destroy()
            
        entry.bind("<Return>", save_schedule_edit)
        entry.bind("<FocusOut>", lambda event: entry.destroy())
        
    def save_current_schedule(self):
        """Save the current schedule to a JSON file"""
        if self.schedule_data is None or self.schedule_data.empty:
            return
            
        data_folder = os.path.join(os.path.dirname(__file__), "data")
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
            
        timestamp = datetime.now().strftime("%d%m%Y%H%M")
        filename = f"RtoL_{timestamp}.json"
        filepath = os.path.join(data_folder, filename)
        
        try:
            self.schedule_data.to_json(filepath, orient="records", date_format="iso")
            # Optional notification about save
            # messagebox.showinfo("Success", f"Schedule saved as JSON: {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving schedule JSON: {e}")

    def clear_schedule(self):
        """Clears the current schedule data and view."""
        # Define standard columns for an empty schedule
        empty_cols = [
            "Part Number", "Cascade Level", "Component Type",
            "Check Start", "Check End", "Release Start", "Release End", "ME Need"
        ]
        self.schedule_data = pd.DataFrame(columns=empty_cols)
        self.update_schedule_view()
        messagebox.showinfo("Cleared", "Schedule cleared. Ready for new generation or loading.")
